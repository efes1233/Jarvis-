// Çok sağlayıcılı "beyin": Gemini, OpenAI, Claude, Grok ve diğerlerinin anahtarları Render'a girilir; her istek işine göre
// sağlayıcıya yönlenir (hızlı sohbet · derin analiz · görüntü/ses), model adları sağlayıcının kendi listesinden bulunur
// ve biri hata verirse (anahtar, limit, kapanan model, çökme) otomatik sıradakine geçilir. Saf mantık: ağ çağrısı dışarıdan verilir.

export type Rol = 'sohbet' | 'derin' | 'gorsel';
export const ROLLER: Rol[] = ['sohbet', 'derin', 'gorsel'];

export interface Saglayici {
  id: string;
  ad: string;
  url: string;
  anahtar: string;
  /** true: model adı olduğu gibi geçer (Abacus RouteLLM, yerel Ollama, elle yazılmış adres) */
  ozel: boolean;
  /** Elle belirlenmiş model adları (ör. OPENAI_MODEL_DERIN) */
  model: Partial<Record<Rol, string>>;
}

interface Bilinen { ad: string; url: string; env: string[]; onek?: RegExp }
export const BILINEN: Record<string, Bilinen> = {
  gemini: { ad: 'Google Gemini', url: 'https://generativelanguage.googleapis.com/v1beta/openai', env: ['GEMINI_API_KEY', 'GOOGLE_API_KEY'], onek: /^AIza/ },
  openai: { ad: 'OpenAI', url: 'https://api.openai.com/v1', env: ['OPENAI_API_KEY'], onek: /^sk-(?!ant-|or-)/ },
  anthropic: { ad: 'Anthropic Claude', url: 'https://api.anthropic.com/v1', env: ['ANTHROPIC_API_KEY', 'CLAUDE_API_KEY'], onek: /^sk-ant-/ },
  xai: { ad: 'xAI Grok', url: 'https://api.x.ai/v1', env: ['XAI_API_KEY', 'GROK_API_KEY'], onek: /^xai-/ },
  groq: { ad: 'Groq', url: 'https://api.groq.com/openai/v1', env: ['GROQ_API_KEY'], onek: /^gsk_/ },
  openrouter: { ad: 'OpenRouter', url: 'https://openrouter.ai/api/v1', env: ['OPENROUTER_API_KEY'], onek: /^sk-or-/ },
  deepseek: { ad: 'DeepSeek', url: 'https://api.deepseek.com/v1', env: ['DEEPSEEK_API_KEY'] },
  mistral: { ad: 'Mistral', url: 'https://api.mistral.ai/v1', env: ['MISTRAL_API_KEY'] },
};

const VARSAYILAN_SIRA: Record<Rol, string[]> = {
  sohbet: ['ozel', 'gemini', 'openai', 'anthropic', 'xai', 'groq', 'deepseek', 'mistral', 'openrouter'],
  derin: ['ozel', 'anthropic', 'openai', 'xai', 'gemini', 'deepseek', 'mistral', 'openrouter', 'groq'],
  gorsel: ['ozel', 'gemini', 'openai', 'anthropic', 'xai', 'openrouter'],
};

/** Model listesi alınamazsa son çare tahminler (alias adları; listeden bulunan her zaman önce gelir). */
const TAHMIN: Record<string, Record<Rol, string>> = {
  gemini: { sohbet: 'gemini-3.8-flash', derin: 'gemini-3.8-flash', gorsel: 'gemini-3.8-flash' },
  openai: { sohbet: 'gpt-5-mini', derin: 'gpt-5', gorsel: 'gpt-5-mini' },
  anthropic: { sohbet: 'claude-haiku-5-5', derin: 'claude-sonnet-5-5', gorsel: 'claude-sonnet-5-5' },
  xai: { sohbet: 'grok-4', derin: 'grok-4', gorsel: 'grok-4' },
  groq: { sohbet: 'llama-3.3-70b-versatile', derin: 'llama-3.3-70b-versatile', gorsel: 'llama-3.3-70b-versatile' },
  deepseek: { sohbet: 'deepseek-chat', derin: 'deepseek-reasoner', gorsel: 'deepseek-chat' },
  mistral: { sohbet: 'mistral-small-latest', derin: 'mistral-large-latest', gorsel: 'mistral-large-latest' },
  openrouter: { sohbet: 'openrouter/auto', derin: 'openrouter/auto', gorsel: 'openrouter/auto' },
};

type Env = Record<string, string | undefined>;
const temiz = (s: string | undefined) => (s ?? '').trim().replace(/^["']|["']$/g, '');

export function maskele(k: string): string {
  return k.length <= 10 ? '••••' : `${k.slice(0, 4)}…${k.slice(-3)}`;
}

/** Ortam değişkenlerinden sağlayıcıları bul. Sıra: elle yazılmış/eski anahtar, sağlayıcıya özel değişkenler, toplu liste. */
export function saglayicilariBul(env: Env): Saglayici[] {
  const out: Saglayici[] = [];
  const var_ = (id: string) => out.some(s => s.id === id);
  const modelEnv = (id: string): Partial<Record<Rol, string>> => {
    const P = id.toUpperCase();
    const g = (k: string) => temiz(env[k]) || undefined;
    const ortak = g(`${P}_MODEL`);
    return { sohbet: g(`${P}_MODEL_SOHBET`) ?? ortak, derin: g(`${P}_MODEL_DERIN`) ?? ortak, gorsel: g(`${P}_MODEL_GORSEL`) ?? ortak };
  };
  const ekle = (id: string, anahtar: string, url?: string) => {
    if (var_(id)) return;
    const b = BILINEN[id];
    out.push({ id, ad: b.ad, url: (temiz(env[`${id.toUpperCase()}_BASE_URL`]) || url || b.url).replace(/\/+$/, ''), anahtar, ozel: false, model: modelEnv(id) });
  };

  // 1) Eski/genel değişkenler (LLM_API_KEY, ABACUS_API_KEY + adres): anahtara bakıp doğru sağlayıcıya yönlendir.
  const eskiAnahtar = temiz(env.LLM_API_KEY) || temiz(env.ABACUS_API_KEY);
  const eskiAdres = (temiz(env.LLM_BASE_URL) || temiz(env.ROUTELLM_BASE_URL)).replace(/\/+$/, '');
  const adresAbacus = !eskiAdres || /abacus\.ai/i.test(eskiAdres);
  const yerel = /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:|\/|$)/i.test(eskiAdres);
  if (eskiAnahtar || yerel) {
    const taninan = Object.entries(BILINEN).find(([, b]) => b.onek?.test(eskiAnahtar));
    if (taninan && adresAbacus) {
      ekle(taninan[0], eskiAnahtar);
      // Elle yazılan model adı bu sağlayıcıya aittir
      const p = out[out.length - 1];
      const cm = temiz(env.CHAT_MODEL), vm = temiz(env.VISION_MODEL);
      if (cm && cm !== 'route-llm') { p.model.sohbet ??= cm; p.model.derin ??= cm; }
      if (vm) p.model.gorsel ??= vm;
    } else if (eskiAdres || eskiAnahtar) {
      out.push({
        id: 'ozel', ad: yerel ? 'Yerel model' : /abacus\.ai/i.test(eskiAdres || 'abacus.ai') ? 'Abacus RouteLLM' : 'Özel adres',
        url: eskiAdres || 'https://routellm.abacus.ai/v1', anahtar: eskiAnahtar || 'yerel', ozel: true, model: {},
      });
    }
  }
  // 2) Sağlayıcıya özel değişkenler
  for (const [id, b] of Object.entries(BILINEN)) {
    for (const ad of b.env) { const k = temiz(env[ad]); if (k) { ekle(id, k); break; } }
  }
  // 3) Toplu liste: tüm anahtarlar tek değişkende (satır, virgül, noktalı virgül ya da boşlukla ayrılmış)
  for (const k of temiz(env.API_ANAHTARLARI ?? env.BEYIN_ANAHTARLARI).split(/[\s,;]+/).map(temiz).filter(Boolean)) {
    const t = Object.entries(BILINEN).find(([, b]) => b.onek?.test(k));
    if (t) ekle(t[0], k);
  }
  return out;
}

// ------------------------------------------------------------------ Rol belirleme
const DERIN = /(analiz|karşılaştır|karsilastir|ayrıntılı|ayrintili|detaylı|detayli|neden|nasıl çalış|nasil calis|strateji|planla|plan yap|özetle|ozetle|aydınlat|aydinlat|brifing|gündem|gundem|kod\b|algoritma|açıkla|acikla|değerlendir|degerlendir)/i;

export function rolBelirle(govde: unknown, mod = 'dengeli'): Rol {
  const msgs: any[] = Array.isArray((govde as any)?.messages) ? (govde as any).messages : [];
  const cokluOrtam = msgs.some(m => Array.isArray(m?.content) && m.content.some((p: any) => p?.type === 'image_url' || p?.type === 'input_audio'));
  if (cokluOrtam) return 'gorsel';
  if (mod === 'hizli') return 'sohbet';
  if (mod === 'guclu') return 'derin';
  const son = [...msgs].reverse().find(m => m?.role === 'user');
  const metin = typeof son?.content === 'string' ? son.content : Array.isArray(son?.content) ? son.content.map((p: any) => p?.text ?? '').join(' ') : '';
  return metin.length > 240 || DERIN.test(metin) ? 'derin' : 'sohbet';
}

// ------------------------------------------------------------------ Model seçimi
const ELE = /(embed|whisper|tts|audio|transcribe|realtime|image|imagen|dall|moderation|guard|safeguard|search|computer|codex|davinci|babbage|instruct|vision-preview|-live|robot|^ft:|:ft|batch|deprecated|legacy|\d{4}-\d{2}-\d{2}$)/i;
const DAHIL: Record<string, RegExp> = {
  openai: /^(gpt-|o\d)/i, anthropic: /^claude-/i, xai: /^grok-/i, gemini: /^gemini-\d/i, groq: /./, deepseek: /^deepseek-(chat|reasoner)/i,
  mistral: /^(mistral|magistral|ministral)/i, openrouter: /./,
};
const HIZLI = /(mini|nano|haiku|flash|lite|fast|small|instant|8b|7b)/i;
const PAHALI = /(\bpro\b|-pro|opus|fable|mythos|reasoner|large)/i;

function surum(id: string): number[] {
  const n = (id.match(/\d+(?:\.\d+)?/g) ?? []).map(Number).filter(x => x < 100);
  return [n[0] ?? 0, n[1] ?? 0];
}

/** Modeller listesinden role en uygun olanı seç; uygun yoksa null. */
export function enIyiModel(idler: string[], saglayiciId: string, rolIstenen: Rol): string | null {
  // Gemini: derin istekte de hızlı "flash" tercih edilir (Pro modellerin ücretsiz kotası çoğunlukla yoktur)
  const rol: Rol = saglayiciId === 'gemini' ? 'sohbet' : rolIstenen;
  const dahil = DAHIL[saglayiciId] ?? /./;
  const aday = idler.map(x => x.replace(/^models\//, '')).filter(id => id && dahil.test(id) && !ELE.test(id));
  if (!aday.length) return null;
  const hizliTercih = rol !== 'derin';
  const anahtar = (id: string) => {
    const h = HIZLI.test(id);
    const [a, b] = surum(id);
    const sonnetMi = saglayiciId === 'anthropic' && /sonnet/i.test(id);
    return [
      hizliTercih ? (h ? 0 : 1) : (h ? 1 : 0), // rolün istediği sınıf
      rol === 'derin' && sonnetMi ? 0 : PAHALI.test(id) ? 1 : 0, // pahalı ailelerden kaçın (elle seçilmedikçe); Claude'da dengeli sonnet
      /nano|lite/i.test(id) ? 1 : 0,
      -a, -b,
      /preview|exp|beta/i.test(id) ? 1 : 0,
    ];
  };
  aday.sort((x, y) => {
    const kx = anahtar(x), ky = anahtar(y);
    for (let i = 0; i < kx.length; i++) if (kx[i] !== ky[i]) return kx[i] - ky[i];
    return x.localeCompare(y);
  });
  return aday[0];
}

// ------------------------------------------------------------------ Yönetici
export interface HttpHata { status: number; body: string }
const httpHataMi = (e: unknown): e is HttpHata => typeof (e as any)?.status === 'number' && typeof (e as any)?.body === 'string';

export interface SaglikKaydi { cezaBitis: number; sonHata: string | null; sonBasari: number | null; ardisikHata: number }
export interface Cagri { listele(s: Saglayici): Promise<string[]> }

export interface BeyinSecenek {
  env: Env;
  /** Model listesi (GET /models). Testte sahte verilir. */
  listele: (s: Saglayici) => Promise<string[]>;
  simdi?: () => number;
  log?: (m: string) => void;
}

export class Beyin {
  readonly saglayicilar: Saglayici[];
  readonly mod: string;
  private env: Env;
  private listele: BeyinSecenek['listele'];
  private simdi: () => number;
  private log: (m: string) => void;
  private saglik = new Map<string, SaglikKaydi>();
  private modelOnbellek = new Map<string, { at: number; ids: string[] }>();
  private secilen = new Map<string, string>();
  private dusunmeKapali = new Set<string>();

  constructor(o: BeyinSecenek) {
    this.env = o.env;
    this.listele = o.listele;
    this.simdi = o.simdi ?? (() => Date.now());
    this.log = o.log ?? (() => {});
    this.saglayicilar = saglayicilariBul(o.env);
    this.mod = temiz(o.env.BEYIN_MOD) || 'dengeli';
    for (const s of this.saglayicilar) this.saglik.set(s.id, { cezaBitis: 0, sonHata: null, sonBasari: null, ardisikHata: 0 });
  }

  get bos(): boolean { return this.saglayicilar.length === 0; }

  /** Rol için sağlayıcı sırası: elle yazılan sıra önce, sonra varsayılan; cezalı olanlar sona. */
  sira(rol: Rol): Saglayici[] {
    const elle = temiz(this.env[`BEYIN_${rol.toUpperCase()}`]).split(/[\s,;]+/).map(x => x.toLowerCase()).filter(Boolean);
    const sadece = temiz(this.env.BEYIN_SADECE) === '1';
    const siralama = sadece && elle.length ? elle : [...elle, ...VARSAYILAN_SIRA[rol]];
    const goruldu = new Set<string>();
    const hepsi: Saglayici[] = [];
    for (const id of siralama) {
      const s = this.saglayicilar.find(x => x.id === id);
      if (s && !goruldu.has(id)) { goruldu.add(id); hepsi.push(s); }
    }
    const t = this.simdi();
    const saglam = hepsi.filter(s => (this.saglik.get(s.id)?.cezaBitis ?? 0) <= t);
    const cezali = hepsi.filter(s => (this.saglik.get(s.id)?.cezaBitis ?? 0) > t);
    return [...saglam, ...cezali];
  }

  /** Sağlayıcı için rolün modelini bul: elle yazılan > listeden en iyi > tahmin. */
  async modelSec(s: Saglayici, rol: Rol, yenile = false): Promise<string | undefined> {
    if (s.ozel) return undefined; // olduğu gibi geçer
    const elle = s.model[rol];
    if (elle) return elle;
    const k = `${s.id}:${rol}`;
    if (!yenile && this.secilen.has(k)) return this.secilen.get(k);
    let ids: string[] = [];
    const onb = this.modelOnbellek.get(s.id);
    if (!yenile && onb && this.simdi() - onb.at < 6 * 3600_000) ids = onb.ids;
    else {
      try { ids = await this.listele(s); this.modelOnbellek.set(s.id, { at: this.simdi(), ids }); } catch { ids = onb?.ids ?? []; }
    }
    const m = enIyiModel(ids, s.id, rol) ?? TAHMIN[s.id]?.[rol];
    if (m) this.secilen.set(k, m);
    return m;
  }

  private ceza(id: string, ms: number, mesaj: string) {
    const k = this.saglik.get(id)!;
    k.cezaBitis = this.simdi() + ms;
    k.sonHata = mesaj;
    k.ardisikHata++;
  }
  private basari(id: string) {
    const k = this.saglik.get(id)!;
    k.cezaBitis = 0; k.sonHata = null; k.sonBasari = this.simdi(); k.ardisikHata = 0;
  }

  /** Sağlayıcıya özgü gövde uyarlaması. */
  uyarla(s: Saglayici, govde: Record<string, any>, model: string | undefined): Record<string, any> {
    const b: Record<string, any> = { ...govde };
    if (model) b.model = model;
    if (s.id === 'gemini' || s.id === 'openai') {
      // Düşünen modeller sesli asistanda ilk kelimeyi geciktirir: düşünmeyi kıs (reddederse bir daha gönderilmez)
      if (!this.dusunmeKapali.has(s.id) && !('reasoning_effort' in b)) b.reasoning_effort = temiz(this.env.LLM_DUSUNME) || 'low';
    }
    if (s.id === 'openai') {
      if ('max_tokens' in b) { b.max_completion_tokens = b.max_tokens; delete b.max_tokens; }
      if (/^(o\d|gpt-5)/i.test(String(b.model))) delete b.temperature;
    }
    if (s.id === 'anthropic' && b.max_tokens == null && b.max_completion_tokens == null) b.max_tokens = 4096;
    return b;
  }

  /**
   * Rolün sağlayıcı sırasıyla çalıştır. Hata olursa sıradakine geç.
   * `calistir(s, govde)` tek bir sağlayıcıya yapılan gerçek istektir. Akışta içerik başladıysa hata `kismi` etiketliyse geçiş yapılmaz.
   */
  async calistir<T>(rol: Rol, govde: Record<string, any>, calistir: (s: Saglayici, b: Record<string, any>) => Promise<T>): Promise<T> {
    const sira = this.sira(rol);
    if (!sira.length) throw Object.assign(new Error('Hiç yapay zekâ anahtarı tanımlı değil'), { status: 401, body: 'anahtar yok' });
    const ozet: { id: string; ad: string; durum: number | null; mesaj: string }[] = [];
    let son: unknown;
    for (const s of sira) {
      let yenilendi = false;
      for (let deneme = 0; deneme < 3; deneme++) {
        try {
          const model = await this.modelSec(s, rol, yenilendi);
          const r = await calistir(s, this.uyarla(s, govde, model));
          this.basari(s.id);
          return r;
        } catch (e) {
          son = e;
          if ((e as any)?.kismi) throw e; // içerik akmaya başladı: yarıda kalan cevabı başka sağlayıcıyla birleştirme
          const durum = httpHataMi(e) ? e.status : null;
          const govdeMetni = httpHataMi(e) ? e.body : String((e as Error)?.message ?? e);
          if (durum === 400 && /reasoning|thinking/i.test(govdeMetni) && !this.dusunmeKapali.has(s.id)) {
            this.dusunmeKapali.add(s.id); // bu sağlayıcı düşünme ayarını kabul etmiyor: ayarsız aynı modeli yeniden dene
            this.log(`[beyin] ${s.id}: düşünme ayarı reddedildi, ayarsız deneniyor`);
            continue;
          }
          if ((durum === 404 || durum === 400) && /model/i.test(govdeMetni) && /(not found|no longer|does not exist|unsupported|not supported|not available|deprecated|invalid model|unknown model)/i.test(govdeMetni) && !yenilendi) {
            yenilendi = true; // model kapanmış: listeyi yenileyip en iyisini yeniden seç
            this.secilen.delete(`${s.id}:${rol}`); this.modelOnbellek.delete(s.id);
            this.log(`[beyin] ${s.id}: model kullanılamıyor, liste yenileniyor`);
            continue;
          }
          const mesaj = `${durum ?? 'ağ'}: ${govdeMetni.replace(/\s+/g, ' ').slice(0, 140)}`;
          ozet.push({ id: s.id, ad: s.ad, durum, mesaj });
          if (durum === 401 || durum === 403) this.ceza(s.id, 10 * 60_000, 'anahtar geçersiz');
          else if (durum === 429) this.ceza(s.id, 60_000, 'limit doldu');
          else if (durum !== null && durum >= 500) this.ceza(s.id, 30_000, 'sunucu hatası');
          else if (durum === null) this.ceza(s.id, 20_000, 'ulaşılamadı');
          else this.ceza(s.id, 15_000, `hata ${durum}`);
          this.log(`[beyin] ${s.id} başarısız (${mesaj}); ${sira.indexOf(s) < sira.length - 1 ? 'sıradakine geçiliyor' : 'başka sağlayıcı kalmadı'}`);
          break;
        }
      }
    }
    if (son && typeof son === 'object') (son as any).saglayicilar = ozet;
    throw son;
  }

  /** Teşhis için: sağlayıcılar, seçilen modeller, sağlık, rol sıraları. Anahtar maskelidir. */
  durum() {
    const t = this.simdi();
    return {
      mod: this.mod,
      saglayicilar: this.saglayicilar.map(s => {
        const k = this.saglik.get(s.id)!;
        return {
          id: s.id, ad: s.ad, anahtar: maskele(s.anahtar), url: s.url.replace(/^https?:\/\//, ''), ozel: s.ozel,
          model: Object.fromEntries(ROLLER.map(r => [r, s.model[r] ?? this.secilen.get(`${s.id}:${r}`) ?? null])),
          saglikli: k.cezaBitis <= t, sonHata: k.sonHata, sonBasari: k.sonBasari,
        };
      }),
      roller: Object.fromEntries(ROLLER.map(r => [r, this.sira(r).map(s => s.id)])),
    };
  }
}
