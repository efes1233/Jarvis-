/** Kullanıcı yüklediği görsel analizi – camera.ts ile aynı routellm vision yolu */
import { routellm, type ChatResponse } from './routellm.js';

export const VISION_MODEL = process.env.VISION_MODEL || process.env.CHAT_MODEL || 'gemini-2.0-flash';

export async function runVisionDescribe(
  dataUrl: string,
  userPrompt: string,
): Promise<{ text: string; model: string }> {
  const prompt =
    (userPrompt || 'Bu görseli Türkçe açıkla.') +
    '\nKurallar: Yalnızca görüntüde görünenleri söyle. Emin olmadığın yerde belirt. ' +
    'Okunabilir yazıları (OCR) aynen aktar. Kişi kimliği uydurma. En fazla 8 kısa cümle veya madde.';
  const r = await routellm<ChatResponse>('/chat/completions', {
    model: VISION_MODEL,
    messages: [
      {
        role: 'user',
        content: [
          { type: 'text', text: prompt },
          { type: 'image_url', image_url: { url: dataUrl } },
        ],
      },
    ],
  });
  const text = String(r.choices?.[0]?.message?.content ?? '').trim();
  if (!text) throw new Error('Vision modeli boş cevap verdi');
  return { text, model: VISION_MODEL };
}
