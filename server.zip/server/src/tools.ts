import { getNews, type GetNewsArgs } from './news.js';
import { getMarkets, getWeather } from './dashboard.js';
import { wikiLookup } from './wiki.js';
import { addMemory, removeMemory } from './profile.js';
import { checkVideo, findHighlights, latestFromChannel, searchVideos, videoIdFrom } from './youtube.js';
import { lookAtCamera } from './camera.js';
import { control, homeMode, homeState, type DeviceId } from './home.js';
import { addBook, addBookNote, fillInBackground, findBook, setBookStatus } from './library.js';
import { hesapla } from './hesapla.js';
import { namazVakitleri } from './namaz.js';
import { ayEvresi, birimCevir, burcBul, dunyaSaati, krediHesapla, rastgele, sayiYaziya, sonDepremler, tarihHesapla, uykuHesapla } from './araclar.js';

// Not: `strict` alanı bilerek yok (RouteLLM 400 döndürebiliyor).
export const TOOLS = [
  {
    type: 'function',
    function: {
      name: 'get_news',
      description:
        "Türkiye ve dünya gündeminden güncel haberleri birden fazla kaynaktan getirir. Gündem, haber veya 'bugün ne oldu' sorularında mutlaka kullanılır.",
      parameters: {
        type: 'object',
        properties: {
          categories: {
            type: 'array',
            items: { type: 'string', enum: ['gundem', 'ekonomi', 'teknoloji', 'spor', 'dunya', 'bilim', 'kultur-sanat', 'saglik'] },
            description: 'İstenen kategoriler. Boş bırakılırsa tüm kategoriler.',
          },
          exclude_categories: { type: 'array', items: { type: 'string' }, description: "Hariç tutulacak kategoriler (ör. 'spor yok')." },
          since_hours: { type: 'integer', description: 'Kaç saat öncesine kadar. Varsayılan 18.' },
          limit: { type: 'integer', description: 'En fazla kaç haber. Varsayılan 30.' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'get_markets',
      description:
        "TCMB'nin açıkladığı döviz satış kurları (USD, EUR, GBP): son değer, bir önceki iş gününe göre yüzde değişim ve son 7 iş gününün geçmişi (history). Dolar, euro, sterlin ve kur sorularında kullanılır.",
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'get_weather',
      description: 'Kullanıcının şehri için anlık hava durumu ve bugünün tahmini (sıcaklık, hissedilen, en yüksek/en düşük, yağış olasılığı, rüzgâr).',
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'wiki_lookup',
      description:
        "Türkçe Wikipedia'dan (yoksa İngilizce) bir kişi, yer, kurum ya da kavramın özetini, lisanslı fotoğrafının olup olmadığını ve koordinatını getirir. Gerçek kişi/yer/kurum sorularında ve nüfus, yükseklik, tarih gibi sayısal bilgilerde kullanılır.",
      parameters: {
        type: 'object',
        properties: { baslik: { type: 'string', description: 'Sayfa başlığı, ör. "Albert Einstein", "Ankara", "Boğaziçi Köprüsü"' } },
        required: ['baslik'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'kameraya_bak',
      description: "Evdeki kamera cihazından (Jarvis'in gözü) anlık bir kare alır ve görüntü modeline sorar. 'Mutfakta ne var', 'kahve makinesinin önünde fincan var mı', 'kapıya bak' gibi isteklerde kullanılır.",
      parameters: {
        type: 'object',
        properties: {
          kamera: { type: 'string', description: 'Kamera etiketi ya da konumu (ör. "CAM-01", "mutfak"). Belirtilmediyse boş bırak.' },
          soru: { type: 'string', description: 'Karede neye bakılacağı, kullanıcının sorusu' },
        },
        required: ['soru'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'ev_kontrol',
      description: "Akıllı ev cihazlarını kontrol eder ya da durumlarını söyler: salon ışığı, çalışma odası ışığı, Türk kahve makinesi, filtre kahve makinesi. 'Salonun ışığını aç', 'çalışma odasını yüzde 30 yap', 'ışıkları kapat', 'filtre kahveyi demle', 'kahve hazır mı' gibi isteklerde kullanılır.",
      parameters: {
        type: 'object',
        properties: {
          cihaz: { type: 'string', enum: ['salon_isik', 'calisma_isik', 'tum_isiklar', 'turk_kahve', 'filtre_kahve', 'hepsi'], description: '"hepsi" yalnızca durum sormak için' },
          islem: { type: 'string', enum: ['ac', 'kapat', 'ayarla', 'pisir', 'demle', 'durum'] },
          parlaklik: { type: 'integer', description: 'Işık için 1-100' },
          ton: { type: 'string', enum: ['sicak', 'notr', 'soguk'], description: 'Işık rengi' },
          kopuk: { type: 'string', enum: ['az', 'orta', 'bol'], description: 'Türk kahvesi köpüğü' },
          seker: { type: 'string', enum: ['sade', 'az', 'orta', 'sekerli'], description: 'Türk kahvesi şekeri' },
          fincan: { type: 'integer', description: 'Filtre kahve için 1-4 fincan' },
        },
        required: ['cihaz', 'islem'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'hafiza_ekle',
      description: 'Kullanıcı hakkında kalıcı bir notu hafızaya ekler ("unutma", "aklında tut" dediğinde ya da kendisi hakkında yeni ve kalıcı bir bilgi verdiğinde). Hassas bilgi ekleme.',
      parameters: {
        type: 'object',
        properties: { not: { type: 'string', description: 'Üçüncü şahıs, tek cümle. Ör. "Cuma günleri çekim yapıyor."' } },
        required: ['not'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'hafiza_sil',
      description: 'Hafızadaki bir notu kimliğiyle siler ("unut", "bunu sil" dendiğinde ya da not artık doğru değilse).',
      parameters: {
        type: 'object',
        properties: { id: { type: 'string', description: 'Hafıza bölümündeki köşeli parantez içindeki kimlik' } },
        required: ['id'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'kitaplik_ekle',
      description: "Kitaplığa bir kitap ekler (rafta yeri olmadan; El Kontrolü'nde K ile rafa yerleştirilir) ve Jarvis sayfalarını (özet, ana fikirler, yazar, temalar, benzer kitaplar) arka planda doldurur. 'Kitaplığıma Davranış'ı ekle', 'kitabın adı Davranış', 'Sapolsky'nin Davranış kitabı bende var' gibi isteklerde kullanılır.",
      parameters: {
        type: 'object',
        properties: {
          kitap: { type: 'string', description: 'Kitabın adı' },
          yazar: { type: 'string', description: 'Yazar (söylendiyse)' },
        },
        required: ['kitap'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'kitaplik_doldur',
      description: "Kitaplıktaki bir kitabın Jarvis sayfalarını (özet, ana fikirler, yazar hakkında, temalar, neden okumalı, benzer kitaplar) arka planda doldurur ya da yeniden yazar. 'Davranış'ın sayfalarını doldur', 'şu kitabın içini doldur' gibi.",
      parameters: { type: 'object', properties: { kitap: { type: 'string', description: 'Kitabın adı' } }, required: ['kitap'] },
    },
  },
  {
    type: 'function',
    function: {
      name: 'kitaplik_not_ekle',
      description: "Kitaplıktaki bir kitaba not ya da alıntı ekler. 'Davranış'a not ekle: …', 'Mülksüzler'e şu alıntıyı ekle: …' gibi isteklerde kullanılır. Notlar kitap El Kontrolü'nde açılınca sayfalarda görünür.",
      parameters: {
        type: 'object',
        properties: {
          kitap: { type: 'string', description: 'Kitabın adı (kitaplık bölümündeki gibi), ör. "Otostopçunun Galaksi Rehberi"' },
          metin: { type: 'string', description: 'Notun ya da alıntının kendisi; kullanıcının söylediği gibi, kısa' },
          tur: { type: 'string', enum: ['not', 'alinti'], description: 'Varsayılan not. Kitaptan bir cümle aktarılıyorsa alinti.' },
          yazar: { type: 'string', description: 'Kitap kitaplıkta yoksa eklenirken kullanılacak yazar (söylendiyse)' },
        },
        required: ['kitap', 'metin'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'kitaplik_durum',
      description: "Kitaplıktaki bir kitabın okuma durumunu ya da kaldığı sayfayı günceller. 'Tahıla Karşı'yı bitirdim', 'Oblomov'da 120. sayfadayım', 'Anna Karenina'yı okumaya başladım' gibi.",
      parameters: {
        type: 'object',
        properties: {
          kitap: { type: 'string', description: 'Kitabın adı' },
          durum: { type: 'string', enum: ['okunacak', 'okunuyor', 'bitti'] },
          sayfa: { type: 'integer', description: 'Kaldığı sayfa' },
          toplam_sayfa: { type: 'integer', description: 'Kitabın toplam sayfası (söylendiyse)' },
        },
        required: ['kitap'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'mac_ozeti_bul',
      description: "Bir takımın en yeni maç özeti videosunu resmi YouTube kanallarında bulur (beIN SPORTS Türkiye, TRT SPOR, LaLiga, Serie A, UEFA, Premier League, büyük kulüplerin kanalları). 'Fener maçının özetini aç', 'Barça maçını aç' gibi isteklerde kullanılır.",
      parameters: {
        type: 'object',
        properties: {
          takim: { type: 'string', description: 'Takım adı, ör. "Fenerbahçe", "Galatasaray", "PSG"' },
          brans: { type: 'string', enum: ['futbol', 'basketbol', 'voleybol'], description: 'Varsayılan futbol. Basketbol/voleybol yalnızca açıkça istenirse.' },
        },
        required: ['takim'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'kanal_son_video',
      description: "Bir YouTube kanalının en son videolarını getirir. 'Son videomu aç', '<kullanıcının adı> son videoyu aç', 'S Sport'un son videosu' gibi isteklerde kullanılır. Kullanıcının kendi kanalı için 'son video' varsayılan olarak son Shorts'tur.",
      parameters: {
        type: 'object',
        properties: {
          kanal: { type: 'string', description: 'Kanal adı. Kullanıcının kendi kanalı için "benim".' },
          tur: { type: 'string', enum: ['shorts', 'video', 'hepsi'], description: 'Yalnızca kullanıcı açıkça "uzun video", "normal video" ya da "shorts" derse ver. Boş bırakılırsa kendi kanalında shorts, diğerlerinde hepsi.' },
        },
        required: ['kanal'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'youtube_ara',
      description: 'YouTube\'da video arar (Jarvis içinde oynatılabilen videolar). "… videosunu aç", "… ile ilgili bir video göster" gibi isteklerde kullanılır.',
      parameters: {
        type: 'object',
        properties: { sorgu: { type: 'string', description: 'Arama sorgusu, ör. "James Webb teleskobu yeni görüntüler"' } },
        required: ['sorgu'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'youtube_ac',
      description: 'Kullanıcının verdiği YouTube linkini (ya da video kimliğini) doğrular; Jarvis içinde oynatılabiliyorsa bilgisini döndürür.',
      parameters: {
        type: 'object',
        properties: { link: { type: 'string', description: 'YouTube linki' } },
        required: ['link'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'hesapla',
      description: 'Matematik işlemini kesin hesaplar (toplama, çıkarma, çarpma, bölme, yüzde, KDV, taksit, birim çevirme, kuvvet, karekök). Sonucu asla kendin tahmin etme, bu aracı çağır.',
      parameters: {
        type: 'object',
        properties: { ifade: { type: 'string', description: 'Ondalık için NOKTA kullan. Örn. "1250*18%", "(2400+360)/12", "sqrt(144)", "100*(1+25%)". Fonksiyonlar: sqrt abs round floor ceil min max mod pow ln log10 sin cos tan; sabitler: pi e.' } },
        required: ['ifade'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'namaz_vakitleri',
      description: 'Bugünün namaz vakitlerini (imsak, güneş, öğle, ikindi, akşam, yatsı) ve sıradaki vakte kalan süreyi verir. Ezan, iftar, sahur saati sorulduğunda kullan; saati kendin söyleme.',
      parameters: {
        type: 'object',
        properties: { sehir: { type: 'string', description: 'Türkiye\'de şehir adı. Boşsa varsayılan şehir.' } },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'birim_cevir',
      description: 'Birim çevirir: uzunluk, kütle, hacim, hız, alan, zaman, sıcaklık (km-mil, kg-lb, C-F, dönüm-m2, galon-litre). Sonucu kendin hesaplama, bu aracı çağır.',
      parameters: {
        type: 'object',
        properties: {
          deger: { type: 'number', description: 'Çevrilecek sayı' },
          kaynak: { type: 'string', description: 'Kaynak birim, ör. km, mil, kg, lb, C, F, dönüm' },
          hedef: { type: 'string', description: 'Hedef birim' }
        },
        required: ["deger", "kaynak", "hedef"],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'tarih_hesapla',
      description: 'Tarih hesapları: iki tarih arası gün farkı, tarihe gün ekleme, haftanın günü, bir tarihe kaç gün kaldı, yaş. Tarihi YYYY-AA-GG yaz (ör. 2026-12-31). Tarihleri kendin hesaplama.',
      parameters: {
        type: 'object',
        properties: {
          islem: { type: 'string', enum: ['fark', 'ekle', 'haftanin_gunu', 'kalan_gun', 'yas'], description: 'fark: tarih1 den tarih2 ye · ekle: tarih1 + gun · haftanin_gunu · kalan_gun: bugunden tarih1 e · yas: tarih1 dogum tarihi' },
          tarih1: { type: 'string', description: 'YYYY-AA-GG' },
          tarih2: { type: 'string', description: 'YYYY-AA-GG (yalnızca fark için)' },
          gun: { type: 'number', description: 'Eklenecek gün (negatif olabilir; yalnızca ekle için)' }
        },
        required: ["islem"],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'rastgele',
      description: 'Gerçekten rastgele: zar atar, yazı tura atar, aralıktan sayı seçer ya da seçenekler arasından birini seçer. Rastgele sonucu kendin uydurma.',
      parameters: {
        type: 'object',
        properties: {
          tur: { type: 'string', enum: ['zar', 'yazi_tura', 'sayi', 'secim'] },
          adet: { type: 'number', description: 'Zar sayısı (1-10)' },
          yuz: { type: 'number', description: 'Zarın yüz sayısı (varsayılan 6)' },
          min: { type: 'number', description: 'En küçük sayı (sayi için)' },
          max: { type: 'number', description: 'En büyük sayı (sayi için)' },
          secenekler: { type: 'array', items: { type: 'string' }, description: 'secim için seçenekler' }
        },
        required: ["tur"],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'dunya_saati',
      description: 'Dünyadaki bir şehirde saat kaç ve İstanbul ile farkı. Saat dilimini ve yaz saatini kendin hesaplama.',
      parameters: {
        type: 'object',
        properties: {
          sehir: { type: 'string', description: 'Şehir adı, ör. Tokyo, New York, Londra' }
        },
        required: ["sehir"],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'ay_evresi',
      description: 'Ay evresi (yeni ay, hilal, dolunay...), aydınlık yüzdesi ve sonraki dolunay ile yeni ay tarihi. Tarih verilmezse bugün.',
      parameters: {
        type: 'object',
        properties: {
          tarih: { type: 'string', description: 'YYYY-AA-GG (isteğe bağlı)' }
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'kredi_hesapla',
      description: 'Kredi ve taksit hesabı: aylık taksit, toplam ödeme ve toplam faiz. Faiz AYLIK yüzde olarak verilir (yıllık faizi 12 ye bölerek aylığa çevir).',
      parameters: {
        type: 'object',
        properties: {
          anapara: { type: 'number', description: 'Çekilen tutar' },
          aylik_faiz_yuzde: { type: 'number', description: 'Aylık faiz, yüzde olarak (ör. 3)' },
          vade_ay: { type: 'number', description: 'Vade, ay' }
        },
        required: ["anapara", "aylik_faiz_yuzde", "vade_ay"],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'uyku_hesapla',
      description: 'Uyku döngüsü (90 dk) hesabı: kalkış saatine göre yatış saatleri ya da yatış saatine göre kalkış saatleri.',
      parameters: {
        type: 'object',
        properties: {
          kalkis: { type: 'string', description: 'Kalkış saati HH:MM' },
          yatis: { type: 'string', description: 'Yatış saati HH:MM' }
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'burc_bul',
      description: 'Doğum gün ve ayından burcu bulur.',
      parameters: {
        type: 'object',
        properties: {
          gun: { type: 'number', description: 'Ayın günü' },
          ay: { type: 'number', description: 'Ay (1-12)' }
        },
        required: ["gun", "ay"],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'sayi_yaziya',
      description: 'Bir sayıyı Türkçe yazıyla yazar (ör. 1250: bin iki yüz elli). Yalnızca tam sayı.',
      parameters: {
        type: 'object',
        properties: {
          sayi: { type: 'number', description: 'Tam sayı' }
        },
        required: ["sayi"],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'son_depremler',
      description: 'Türkiye çevresindeki son depremleri listeler (USGS verisi). Büyüklüğü ve zamanı kendin uydurma.',
      parameters: {
        type: 'object',
        properties: {
          min_buyukluk: { type: 'number', description: 'En küçük büyüklük (varsayılan 4)' },
          adet: { type: 'number', description: 'Kaç deprem (1-10, varsayılan 5)' }
        },
      },
    },
  },
] as const;

export type ToolProgress = (line: string) => void;

export async function runTool(name: string, rawArgs: string, progress: ToolProgress): Promise<string> {
  let args: any = {};
  try {
    args = rawArgs ? JSON.parse(rawArgs) : {};
  } catch {
    args = {};
  }
  if (name === 'get_news') {
    progress('haber kaynakları taranıyor');
    const res = await getNews(args as GetNewsArgs);
    progress(`${res.sources_scanned} kaynak tarandı · ${res.items.length} haber bulundu`);
    // Modele giden çıktıyı sade tut: fotoğraf URL'si göndermiyoruz.
    return JSON.stringify({
      ...res,
      items: res.items.map(({ image_url, url, ...rest }) => ({ ...rest, has_photo: !!image_url })),
    });
  }
  if (name === 'get_markets') {
    progress('piyasa verileri alınıyor');
    const m = await getMarkets();
    return JSON.stringify(m ?? { error: 'Piyasa verisi şu an alınamıyor. Rakam söyleme.' });
  }
  if (name === 'get_weather') {
    progress('hava durumu alınıyor');
    const w = await getWeather();
    return JSON.stringify(w ?? { error: 'Hava durumu şu an alınamıyor. Rakam söyleme.' });
  }
  if (name === 'wiki_lookup') {
    const baslik = String(args.baslik ?? args.title ?? '');
    progress(`wikipedia: ${baslik}`);
    const w = await wikiLookup(baslik).catch(() => null);
    if (!w) return JSON.stringify({ error: `Wikipedia'da bulunamadı: ${baslik}. Bu konuda rakam söyleme.` });
    // Modele fotoğraf adresi gitmez (model URL yazmaz); fotoğrafı sunucu "wiki" alanındaki başlıktan ekler.
    const { foto, ...rest } = w;
    return JSON.stringify({ ...rest, foto: foto ? { var: true, lisans: foto.lisans, yazar: foto.yazar } : null });
  }
  if (name === 'mac_ozeti_bul') {
    const takim = String(args.takim ?? '');
    progress(`maç özeti aranıyor: ${takim}`);
    const brans = ['futbol', 'basketbol', 'voleybol'].includes(args.brans) ? args.brans : 'futbol';
    const r = await findHighlights(takim, brans).catch(e => ({ videolar: [] as unknown[], taranan: [] as string[], hata: String(e.message) }));
    progress(r.videolar.length ? `${r.videolar.length} video bulundu` : 'özet bulunamadı');
    return JSON.stringify(r.videolar.length ? r : {
      ...r,
      sonuc: `Taranan kanallarda bu takımın ${brans} videosu yok. Uydurma; bulamadığını söyle. "diger_brans" varsa (ör. basketbol) bunu söyleyip açmayı yalnızca TEKLİF ET, kendiliğinden açma.`,
    });
  }
  if (name === 'youtube_ara') {
    const sorgu = String(args.sorgu ?? '');
    progress(`youtube: ${sorgu}`);
    const r = await searchVideos(sorgu).catch(e => ({ hata: String(e.message) }));
    if (r === null) return JSON.stringify({ hata: 'YouTube araması kurulmadı (YOUTUBE_API_KEY yok). Kullanıcıya bunu söyle; bir YouTube linki verirse onu açabileceğini ekle.' });
    if ('hata' in r) return JSON.stringify(r);
    progress(`${r.length} video bulundu`);
    return JSON.stringify(r.length ? { videolar: r } : { sonuc: 'Sonuç yok.' });
  }
  if (name === 'kanal_son_video') {
    const kanal = String(args.kanal ?? '');
    const tur = ['shorts', 'video', 'hepsi'].includes(args.tur) ? args.tur : undefined;
    progress(`kanal: ${kanal}${tur ? ` · ${tur}` : ''}`);
    const r = await latestFromChannel(kanal, tur).catch(e => ({ hata: String(e.message) }));
    if (!('hata' in r)) progress(`${r.videolar.length} video bulundu`);
    return JSON.stringify(r);
  }
  if (name === 'youtube_ac') {
    const id = videoIdFrom(String(args.link ?? ''));
    if (!id) return JSON.stringify({ hata: 'Bu bir YouTube linkine benzemiyor.' });
    progress('video kontrol ediliyor');
    const r = await checkVideo(id).catch(() => ({ hata: 'Video kontrol edilemedi.' }));
    return JSON.stringify(r);
  }
  if (name === 'kameraya_bak') {
    progress(`kameraya bakılıyor${args.kamera ? `: ${args.kamera}` : ''}`);
    const r: any = await lookAtCamera(String(args.kamera ?? ''), String(args.soru ?? ''));
    progress(r.hata ? 'kamera: görüntü yok' : `${r.kamera} karesi yorumlandı`);
    return JSON.stringify(r);
  }
  if (name === 'ev_kontrol') {
    const cihaz = String(args.cihaz ?? '');
    const ids: DeviceId[] = cihaz === 'tum_isiklar' ? ['salon_isik', 'calisma_isik'] : cihaz === 'hepsi' ? [] : [cihaz as DeviceId];
    if (cihaz === 'hepsi' || args.islem === 'durum') {
      const all = homeState().devices;
      return JSON.stringify({ mod: homeMode(), cihazlar: cihaz === 'hepsi' ? all : all.filter(d => ids.includes(d.id)) });
    }
    const out = ids.map(id => {
      const r = control(id, args);
      return 'hata' in r ? { cihaz: id, hata: r.hata } : { cihaz: r.cihaz.ad, sonuc: r.ozet };
    });
    progress(out.map(o => ('hata' in o ? `${o.cihaz}: ${o.hata}` : `${o.cihaz}: ${o.sonuc}`)).join(' · '));
    return JSON.stringify({ mod: homeMode(), sonuclar: out });
  }
  if (name === 'kitaplik_ekle') {
    const r: any = addBook(String(args.kitap ?? ''), args.yazar ? String(args.yazar) : null);
    progress('hata' in r ? `kitaplık: ${r.hata}` : r.yeni ? `kitaplığa eklendi: ${r.kitap.ad}` : `zaten kitaplıkta: ${r.kitap.ad}`);
    if ('hata' in r) return JSON.stringify(r);
    const dolduruluyor = !r.kitap.jarvis;
    if (dolduruluyor) fillInBackground(r.kitap.id);
    return JSON.stringify({ ok: true, kitap: r.kitap.ad, yazar: r.kitap.yazar, yeni: r.yeni, raftaYeri: !!r.kitap.kutu, sayfalarDolduruluyor: dolduruluyor });
  }
  if (name === 'kitaplik_doldur') {
    const f: any = findBook(String(args.kitap ?? ''));
    if ('hata' in f) return JSON.stringify(f);
    fillInBackground(f.kitap.id);
    progress(`${f.kitap.ad}: sayfalar dolduruluyor`);
    return JSON.stringify({ ok: true, kitap: f.kitap.ad, sayfalarDolduruluyor: true });
  }
  if (name === 'kitaplik_not_ekle') {
    const r: any = addBookNote(String(args.kitap ?? ''), String(args.metin ?? ''), args.tur === 'alinti' ? 'alinti' : 'not', args.yazar ? String(args.yazar) : undefined);
    progress(r.hata ? `kitaplık: ${r.hata}` : `${r.kitap}: ${r.tur === 'alinti' ? 'alıntı' : 'not'} eklendi`);
    console.log(`[kitaplık] ${r.hata ? `not eklenemedi: ${r.hata}` : `${r.kitap} · ${r.tur} eklendi`}`);
    return JSON.stringify(r);
  }
  if (name === 'kitaplik_durum') {
    const r: any = setBookStatus(String(args.kitap ?? ''), args);
    progress(r.hata ? `kitaplık: ${r.hata}` : `${r.kitap}: ${r.durum}${r.sayfa ? `, s. ${r.sayfa}` : ''}`);
    return JSON.stringify(r);
  }
  if (name === 'hesapla') {
    const ifade = String(args.ifade ?? '');
    progress(`hesaplanıyor: ${ifade.slice(0, 60)}`);
    try {
      return JSON.stringify({ ifade, sonuc: hesapla(ifade) });
    } catch (e) {
      return JSON.stringify({ hata: `Hesaplanamadı: ${(e as Error).message}. İfadeyi düzeltip yeniden dene ya da kullanıcıya söyle; sonucu tahmin etme.` });
    }
  }
  if (name === 'namaz_vakitleri') {
    const sehir = typeof args.sehir === 'string' ? args.sehir : undefined;
    progress(`namaz vakitleri${sehir ? `: ${sehir}` : ''}`);
    return JSON.stringify(await namazVakitleri(sehir));
  }
  if (name === 'birim_cevir' || name === 'tarih_hesapla' || name === 'rastgele' || name === 'dunya_saati' || name === 'ay_evresi'
    || name === 'kredi_hesapla' || name === 'uyku_hesapla' || name === 'burc_bul' || name === 'sayi_yaziya' || name === 'son_depremler') {
    progress(name.replace(/_/g, ' '));
    const sayi = (x: unknown) => (x === undefined || x === null || x === '' ? undefined : Number(x));
    try {
      switch (name) {
        case 'birim_cevir': return JSON.stringify(birimCevir(Number(args.deger), String(args.kaynak ?? ''), String(args.hedef ?? '')));
        case 'tarih_hesapla': return JSON.stringify(tarihHesapla({ islem: String(args.islem ?? ''), tarih1: args.tarih1 as string | undefined, tarih2: args.tarih2 as string | undefined, gun: sayi(args.gun) }));
        case 'rastgele': return JSON.stringify(rastgele({ tur: String(args.tur ?? ''), adet: sayi(args.adet), yuz: sayi(args.yuz), min: sayi(args.min), max: sayi(args.max), secenekler: Array.isArray(args.secenekler) ? args.secenekler.map(String) : undefined }));
        case 'dunya_saati': return JSON.stringify(dunyaSaati(String(args.sehir ?? '')));
        case 'ay_evresi': return JSON.stringify(ayEvresi(typeof args.tarih === 'string' && args.tarih ? args.tarih : undefined));
        case 'kredi_hesapla': return JSON.stringify(krediHesapla({ anapara: Number(args.anapara), aylik_faiz_yuzde: Number(args.aylik_faiz_yuzde), vade_ay: Number(args.vade_ay) }));
        case 'uyku_hesapla': return JSON.stringify(uykuHesapla({ kalkis: args.kalkis as string | undefined, yatis: args.yatis as string | undefined }));
        case 'burc_bul': return JSON.stringify(burcBul(Number(args.gun), Number(args.ay)));
        case 'sayi_yaziya': return JSON.stringify({ sayi: Number(args.sayi), yazi: sayiYaziya(Number(args.sayi)) });
        default: return JSON.stringify(await sonDepremler({ min_buyukluk: sayi(args.min_buyukluk), adet: sayi(args.adet) }));
      }
    } catch (e) {
      return JSON.stringify({ hata: `${(e as Error).message}. Düzeltip yeniden dene ya da kullanıcıya söyle; sonucu tahmin etme.` });
    }
  }
  if (name === 'hafiza_ekle') {
    const item = addMemory(String(args.not ?? ''));
    progress(item ? `hafızaya eklendi: ${item.text}` : 'not zaten hafızada');
    console.log(`[hafıza] ${item ? `eklendi [${item.id}] ${item.text}` : 'eklenmedi (boş ya da tekrar)'}`);
    return JSON.stringify(item ? { ok: true, id: item.id } : { ok: false, sebep: 'boş ya da zaten var' });
  }
  if (name === 'hafiza_sil') {
    const item = removeMemory(String(args.id ?? ''));
    progress(item ? `hafızadan silindi: ${item.text}` : 'not bulunamadı');
    console.log(`[hafıza] ${item ? `silindi [${item.id}] ${item.text}` : `silinemedi: ${args.id}`}`);
    return JSON.stringify(item ? { ok: true } : { ok: false, sebep: 'bu kimlikte not yok' });
  }
  return JSON.stringify({ error: `Bilinmeyen araç: ${name}` });
}
