# JARVIS PRO – Asset Manifest

## Kullanılan ücretsiz kaynaklar

| Dosya / Kaynak | Kaynak | Lisans | Kullanım yeri |
|----------------|--------|--------|---------------|
| Mixkit uzay / şehir videoları | https://mixkit.co | Mixkit License (ücretsiz ticari) | SinemaPaneli fragmanları |
| Mevcut proje sesleri | Proje içi | Proje | HUD ambient, bildirimler |
| HUD SVG bileşenleri | Proje içi | Proje | Mark2 / HUD |

## Notlar
- Marvel karakter görselleri / sesleri kullanılmamıştır.
- DRM korumalı film içerikleri indirilmemiş / dağıtılmamıştır.
- Film siteleri yalnızca kullanıcı tarafından açılan harici linkler olarak kullanılmaktadır.
- Büyük 4K texture'lar mobil performans için isteğe bağlı bırakılmıştır.

Son güncelleme: 2026-11-12
