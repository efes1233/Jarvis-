// Görünüm ve ses karakteri ayarları (bu cihazda saklanır). Saf mantık: React ya da CSS içe aktarmaz.

function safeGet(k: string) { try { return localStorage.getItem(k); } catch { return null; } }
function safeSet(k: string, v: string) { try { localStorage.setItem(k, v); } catch { /* gizli pencere: yalnızca bu oturum */ } }

// ---------------------------------------------------------------- Renk temaları
export interface Tema { id: string; ad: string; renk: string }
export const TEMALAR: Tema[] = [
  { id: 'klasik', ad: 'Klasik', renk: '#4de1ff' },
  { id: 'altin', ad: 'Altın', renk: '#ffb547' },
  { id: 'kizil', ad: 'Kızıl', renk: '#ff5d5d' },
  { id: 'matrix', ad: 'Matrix', renk: '#5dffb0' },
  { id: 'nebula', ad: 'Nebula', renk: '#b388ff' },
  { id: 'buz', ad: 'Buz', renk: '#e8f6ff' },
];
const TEMA_KEY = 'jarvis.tema';

export function loadTema(): string {
  const v = safeGet(TEMA_KEY);
  return TEMALAR.some(t => t.id === v) ? (v as string) : 'klasik';
}
export function applyTema(id: string): void {
  if (typeof document === 'undefined') return;
  if (id === 'klasik') delete document.documentElement.dataset.tema;
  else document.documentElement.dataset.tema = id;
}
export function setTema(id: string): void {
  if (!TEMALAR.some(t => t.id === id)) return;
  safeSet(TEMA_KEY, id);
  applyTema(id);
}

// ---------------------------------------------------------------- Ses karakterleri (tarayıcı sesi: perde ve hız)
export interface SesKarakter { id: string; ad: string; alt: string; perde: number; hiz: number }
export const KARAKTERLER: SesKarakter[] = [
  { id: 'varsayilan', ad: 'Varsayılan', alt: 'eski ayar', perde: 0.95, hiz: 1 },
  { id: 'jarvis', ad: 'Jarvis', alt: 'derin, sakin', perde: 0.75, hiz: 0.95 },
  { id: 'friday', ad: 'Friday', alt: 'parlak, canlı', perde: 1.25, hiz: 1.04 },
  { id: 'seri', ad: 'Seri', alt: 'hızlı, net', perde: 1, hiz: 1.25 },
  { id: 'agir', ad: 'Ağır', alt: 'çok derin, yavaş', perde: 0.55, hiz: 0.85 },
];
const KARAKTER_KEY = 'jarvis.ses.karakter';

export function loadKarakter(): SesKarakter {
  const v = safeGet(KARAKTER_KEY);
  return KARAKTERLER.find(k => k.id === v) ?? KARAKTERLER[0];
}
export function saveKarakter(id: string): void {
  if (KARAKTERLER.some(k => k.id === id)) safeSet(KARAKTER_KEY, id);
}

// Sayfa açılırken kayıtlı temayı hemen uygula (ilk çizimde yanlış renk görünmesin)
applyTema(loadTema());
