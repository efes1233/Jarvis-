// Hangi sürümün çalıştığını Ayarlar → Tanı'da göster (yama uygulandı mı anlaşılsın)
export const SURUM = 'v5 · çok sağlayıcılı beyin · 2 Kasım 2026';
