// El kontrolü performans profilleri. Telefonda (özellikle iPhone 11) 1080p/60 kamera + her karede el ve yüz
// algılama + 7000 parçacık donmaya yol açar. Profil kamera çözünürlüğünü, algılama sıklığını ve efekt yükünü ayarlar.

export type Profil = 'otomatik' | 'hafif' | 'dengeli' | 'yuksek';
export type GercekProfil = Exclude<Profil, 'otomatik'>;

export interface PerfCfg {
  genislik: number;   // kamera çözünürlüğü
  yukseklik: number;
  fps: number;        // kamera kare hızı
  algilaMs: number;   // iki el algılaması arası en az süre (ms); 0 = her yeni karede
  yuzHer: number;     // yüz algılama her N. karede; 0 = kapalı
  dprTavan: number;   // canvas piksel yoğunluğu üst sınırı
  parcacik: number;   // en çok parçacık
}

export const PROFILLER: Record<GercekProfil, PerfCfg> = {
  hafif:   { genislik: 640,  yukseklik: 480,  fps: 30, algilaMs: 40, yuzHer: 0,  dprTavan: 1,    parcacik: 1800 },
  dengeli: { genislik: 1280, yukseklik: 720,  fps: 30, algilaMs: 33, yuzHer: 6,  dprTavan: 1,    parcacik: 3500 },
  yuksek:  { genislik: 1920, yukseklik: 1080, fps: 60, algilaMs: 0,  yuzHer: 3,  dprTavan: 1.5,  parcacik: 7000 },
};

export const PROFIL_AD: Record<GercekProfil, string> = { hafif: 'hafif', dengeli: 'dengeli', yuksek: 'yüksek' };

/** Canvas'ların (fx, yüz) okuduğu ortak üst sınır. Profil ve yavaşlama koruması değiştirir. */
export const perfState = { dprCap: 1.5 };

export function mobilMi(): boolean {
  const ua = navigator.userAgent;
  return /iPhone|iPad|iPod|Android/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
}

export function profilCoz(p: Profil): GercekProfil {
  if (p !== 'otomatik') return p;
  return mobilMi() ? 'hafif' : 'yuksek'; // telefonda en akıcı profil; isteyen Ayarlar'dan Dengeli/Yüksek seçer
}

const KEY = 'jarvis.el.perf';
export function loadProfil(): Profil {
  try {
    const v = localStorage.getItem(KEY);
    return v === 'hafif' || v === 'dengeli' || v === 'yuksek' ? v : 'otomatik';
  } catch { return 'otomatik'; }
}
export function saveProfil(p: Profil): void {
  try { localStorage.setItem(KEY, p); } catch { /* yok say */ }
}
