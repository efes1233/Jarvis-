import type { EvrenDurum, Mod, Kalite } from '../evren/ciz';

export interface ElOzellik { id: number; grup: string; ad: string; aciklama: string; uygula: (s: EvrenDurum) => void }
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const merkez = (s: EvrenDurum) => { s.lon0 = 29 * Math.PI / 180; s.lat0 = 28 * Math.PI / 180; };
const zoom = (s: EvrenDurum, n: number) => { s.d = clamp(s.d + n, 1.35, 8); };
const renkler = ['77, 225, 255', '80, 255, 190', '255, 190, 90', '190, 150, 255', '255, 110, 150'];
const f: Omit<ElOzellik, 'id'>[] = [
  {grup:'Dünya kamerası',ad:'Dünya görünümü',aciklama:'Dünya moduna geç',uygula:s=>s.mod='dunya'},
  {grup:'Dünya kamerası',ad:'Kuzey kutbu',aciklama:'Kamerayı kuzey kutbuna çevir',uygula:s=>{s.lon0=0;s.lat0=Math.PI/2-.08}},
  {grup:'Dünya kamerası',ad:'Güney kutbu',aciklama:'Kamerayı güney kutbuna çevir',uygula:s=>{s.lon0=0;s.lat0=-Math.PI/2+.08}},
  {grup:'Dünya kamerası',ad:'Ekvator görünümü',aciklama:'Ekvator hizasına dön',uygula:s=>{s.lat0=0}},
  {grup:'Dünya kamerası',ad:'Türkiye odağı',aciklama:'Türkiye merkezli görünüm',uygula:s=>{s.lon0=29*Math.PI/180;s.lat0=39*Math.PI/180;s.d=2.8}},
  {grup:'Dünya kamerası',ad:'Avrupa odağı',aciklama:'Avrupa merkezli görünüm',uygula:s=>{s.lon0=15*Math.PI/180;s.lat0=50*Math.PI/180;s.d=2.7}},
  {grup:'Dünya kamerası',ad:'Asya odağı',aciklama:'Asya merkezli görünüm',uygula:s=>{s.lon0=100*Math.PI/180;s.lat0=35*Math.PI/180;s.d=2.7}},
  {grup:'Dünya kamerası',ad:'Amerika odağı',aciklama:'Kuzey Amerika merkezli görünüm',uygula:s=>{s.lon0=-100*Math.PI/180;s.lat0=40*Math.PI/180;s.d=2.7}},
  {grup:'Dünya kamerası',ad:'Yakınlaş',aciklama:'Dünya görünümünü büyüt',uygula:s=>zoom(s,-.45)},
  {grup:'Dünya kamerası',ad:'Uzaklaş',aciklama:'Dünya görünümünü küçült',uygula:s=>zoom(s,.45)},
  {grup:'Dünya kamerası',ad:'Kamera sıfırla',aciklama:'Başlangıç açısına dön',uygula:s=>{merkez(s);s.d=3.3;s.yaw=.5;s.pitch=.9;s.dGunes=9.5}},
  {grup:'Uydu kontrolü',ad:'Uyduları göster',aciklama:'Uydu katmanını aç',uygula:s=>s.uydular=true},
  {grup:'Uydu kontrolü',ad:'Uyduları gizle',aciklama:'Uydu katmanını kapat',uygula:s=>s.uydular=false},
  {grup:'Uydu kontrolü',ad:'Uydu animasyonunu hızlandır',aciklama:'Simülasyon zamanını ileri al',uygula:s=>s.simSn+=900},
  {grup:'Uydu kontrolü',ad:'Uydu animasyonunu yavaşlat',aciklama:'Simülasyon zamanını geri al',uygula:s=>s.simSn=Math.max(0,s.simSn-300)},
  {grup:'Uydu kontrolü',ad:'Bir saat ileri',aciklama:'Yörünge simülasyonunu 1 saat ilerlet',uygula:s=>s.simSn+=3600},
  {grup:'Uydu kontrolü',ad:'Bir tur ileri',aciklama:'Simülasyon zamanını 90 dakika ilerlet',uygula:s=>s.simSn+=5400},
  {grup:'Uydu kontrolü',ad:'ISS konumuna odaklan',aciklama:'Gerçek ISS konumu varsa oraya dön',uygula:s=>{if(s.iss){s.lon0=s.iss.lon;s.lat0=s.iss.lat;s.d=2.4}}},
  {grup:'Uydu kontrolü',ad:'ISS izini merkeze al',aciklama:'ISS görünümüne yakınlaş',uygula:s=>{if(s.iss){s.lon0=s.iss.lon;s.lat0=s.iss.lat;s.d=1.8}}},
  {grup:'Uydu kontrolü',ad:'Uydu görünümünü sıfırla',aciklama:'Uydu simülasyon saatini sıfırla',uygula:s=>s.simSn=0},
  {grup:'Uzay görünümü',ad:'Güneş sistemi',aciklama:'Güneş sistemi görünümüne geç',uygula:s=>s.mod='gunes'},
  {grup:'Uzay görünümü',ad:'Gezegen modu',aciklama:'Seçili gezegen görünümüne geç',uygula:s=>s.mod='gezegen'},
  {grup:'Uzay görünümü',ad:'Güneş sistemi yakınlaştır',aciklama:'Güneş sistemi kamerasını yaklaştır',uygula:s=>s.dGunes=clamp(s.dGunes-.8,3,18)},
  {grup:'Uzay görünümü',ad:'Güneş sistemi uzaklaştır',aciklama:'Güneş sistemi kamerasını uzaklaştır',uygula:s=>s.dGunes=clamp(s.dGunes+.8,3,18)},
  {grup:'Uzay görünümü',ad:'Yörünge açısını sola çevir',aciklama:'Güneş sistemi yaw açısını değiştir',uygula:s=>s.yaw-=.25},
  {grup:'Uzay görünümü',ad:'Yörünge açısını sağa çevir',aciklama:'Güneş sistemi yaw açısını değiştir',uygula:s=>s.yaw+=.25},
  {grup:'Uzay görünümü',ad:'Yörüngeyi yukarı eğ',aciklama:'Güneş sistemi kamera açısını değiştir',uygula:s=>s.pitch=clamp(s.pitch-.18,.15,2.8)},
  {grup:'Uzay görünümü',ad:'Yörüngeyi aşağı eğ',aciklama:'Güneş sistemi kamera açısını değiştir',uygula:s=>s.pitch=clamp(s.pitch+.18,.15,2.8)},
  {grup:'Uzay görünümü',ad:'Simülasyonu 1 gün ilerlet',aciklama:'Gezegen konumlarını bir gün ilerlet',uygula:s=>s.simGun+=1},
  {grup:'Uzay görünümü',ad:'Simülasyonu 30 gün ilerlet',aciklama:'Gezegen konumlarını 30 gün ilerlet',uygula:s=>s.simGun+=30},
  {grup:'Uzay görünümü',ad:'J2000 tarihine dön',aciklama:'Gezegen simülasyon tarihini sıfırla',uygula:s=>s.simGun=0},
  {grup:'İşaretleme',ad:'İstanbul işareti ekle',aciklama:'Haritaya İstanbul işareti ekle',uygula:s=>{s.isaretler=s.isaretler.filter(x=>x.ad!=='İSTANBUL');s.isaretler.push({lon:28.98*Math.PI/180,lat:41.01*Math.PI/180,ad:'İSTANBUL'})}},
  {grup:'İşaretleme',ad:'Şanlıurfa işareti ekle',aciklama:'Haritaya Şanlıurfa işareti ekle',uygula:s=>{s.isaretler=s.isaretler.filter(x=>x.ad!=='ŞANLIURFA');s.isaretler.push({lon:38.79*Math.PI/180,lat:37.16*Math.PI/180,ad:'ŞANLIURFA'})}},
  {grup:'İşaretleme',ad:'Ankara işareti ekle',aciklama:'Haritaya Ankara işareti ekle',uygula:s=>{s.isaretler=s.isaretler.filter(x=>x.ad!=='ANKARA');s.isaretler.push({lon:32.85*Math.PI/180,lat:39.93*Math.PI/180,ad:'ANKARA'})}},
  {grup:'İşaretleme',ad:'İzmir işareti ekle',aciklama:'Haritaya İzmir işareti ekle',uygula:s=>{s.isaretler=s.isaretler.filter(x=>x.ad!=='İZMİR');s.isaretler.push({lon:27.14*Math.PI/180,lat:38.42*Math.PI/180,ad:'İZMİR'})}},
  {grup:'İşaretleme',ad:'İşaretleri temizle',aciklama:'Haritadaki özel işaretleri kaldır',uygula:s=>s.isaretler=[]},
  {grup:'İşaretleme',ad:'İşaretleri varsayılana döndür',aciklama:'Başlangıç işaretini geri getir',uygula:s=>s.isaretler=[{lon:28.98*Math.PI/180,lat:41.01*Math.PI/180,ad:'İSTANBUL'}]},
  {grup:'Görünüm',ad:'Yüksek kalite',aciklama:'Çizim kalitesini yükselt',uygula:s=>s.kalite='yuksek' as Kalite},
  {grup:'Görünüm',ad:'Dengeli kalite',aciklama:'Dengeli çizim kalitesi',uygula:s=>s.kalite='dengeli' as Kalite},
  {grup:'Görünüm',ad:'Hafif kalite',aciklama:'Düşük güç tüketimli çizim',uygula:s=>s.kalite='hafif' as Kalite},
  {grup:'Görünüm',ad:'Mavi HUD rengi',aciklama:'Vurgu rengini mavi yap',uygula:s=>s.rgb=renkler[0]},
  {grup:'Görünüm',ad:'Yeşil HUD rengi',aciklama:'Vurgu rengini yeşil yap',uygula:s=>s.rgb=renkler[1]},
  {grup:'Görünüm',ad:'Altın HUD rengi',aciklama:'Vurgu rengini altın yap',uygula:s=>s.rgb=renkler[2]},
  {grup:'Görünüm',ad:'Mor HUD rengi',aciklama:'Vurgu rengini mor yap',uygula:s=>s.rgb=renkler[3]},
  {grup:'Görünüm',ad:'Pembe HUD rengi',aciklama:'Vurgu rengini pembe yap',uygula:s=>s.rgb=renkler[4]},
  {grup:'Simülasyon',ad:'Zamanı 10 dakika ilerlet',aciklama:'Dünya ve uydu simülasyonunu ilerlet',uygula:s=>s.simSn+=600},
  {grup:'Simülasyon',ad:'Zamanı 10 dakika geri al',aciklama:'Simülasyon zamanını geri sar',uygula:s=>s.simSn=Math.max(0,s.simSn-600)},
  {grup:'Simülasyon',ad:'Gezegen yılına ilerle',aciklama:'Gezegen simülasyonunu bir yıl ileri al',uygula:s=>s.simGun+=365},
  {grup:'Simülasyon',ad:'Kamera eğimini sıfırla',aciklama:'Dünya kamera enlemini sıfırla',uygula:s=>s.lat0=0},
  {grup:'Simülasyon',ad:'Kamera boylamını sıfırla',aciklama:'Dünya kamera boylamını sıfırla',uygula:s=>s.lon0=0},
  {grup:'Simülasyon',ad:'Dünya dönüşünü ileri sar',aciklama:'Dünya simülasyon saatini 6 saat ilerlet',uygula:s=>s.simSn+=21600},
  {grup:'Simülasyon',ad:'Dünya dönüşünü geri sar',aciklama:'Dünya simülasyon saatini 6 saat geri al',uygula:s=>s.simSn=Math.max(0,s.simSn-21600)},
  {grup:'Simülasyon',ad:'Evren durumunu yenile',aciklama:'Kamera ve simülasyon başlangıç değerlerini yükle',uygula:s=>{const n={mod:'dunya' as Mod,lon0:29*Math.PI/180,lat0:28*Math.PI/180,d:3.3,yaw:.5,pitch:.9,dGunes:9.5,simSn:0,simGun:0,uydular:true};Object.assign(s,n)}}
];
export const EVREN_EL_OZELLIKLER: ElOzellik[] = f.map((x,i)=>({...x,id:i+1}));
export function evrenOzellikUygula(s: EvrenDurum,id:number): ElOzellik | undefined { const item=EVREN_EL_OZELLIKLER.find(x=>x.id===id); item?.uygula(s); return item; }
