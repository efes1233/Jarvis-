/**
 * AI Council – dört asistanın aynı soruya sırayla yanıt vermesi.
 * Gerçek paralel multi-model oylama değil; aynı backend + farklı persona ile ardışık çağrı.
 * Kullanıcıya açıkça "sırayla" olduğu belirtilir.
 */
import { sendChat } from '../lib/api';
import type { Device } from '../lib/types';
import { PERSONAS, type PersonaId } from './personas';

export type CouncilResult = {
  persona: PersonaId;
  ad: string;
  renk: string;
  ok: boolean;
  error?: string;
  /** Ham yanıt metni (SSE sahneleri birleşince client tarafında gelir; burada sadece istek tetiklenir) */
};

const ORDER: PersonaId[] = ['jarvis', 'friday', 'ev', 'edith'];

/**
 * Council modunda her persona için ayrı chat isteği gönderir (sırayla).
 * UI, SSE olaylarını dinleyerek sonuçları göstermelidir.
 * Bu fonksiyon sadece istekleri sırayla ateşler ve hangi persona'nın konuştuğunu döner.
 */
export async function runCouncilSequential(
  text: string,
  device: Device,
  onStart?: (id: PersonaId) => void,
  onDone?: (id: PersonaId, ok: boolean, err?: string) => void,
): Promise<CouncilResult[]> {
  const results: CouncilResult[] = [];
  for (const id of ORDER) {
    const p = PERSONAS[id];
    onStart?.(id);
    try {
      await sendChat(`[AI Council · ${p.ad}] ${text}`, device, undefined, id);
      results.push({ persona: id, ad: p.ad, renk: p.renk, ok: true });
      onDone?.(id, true);
    } catch (e: any) {
      results.push({ persona: id, ad: p.ad, renk: p.renk, ok: false, error: String(e?.message || e) });
      onDone?.(id, false, String(e?.message || e));
    }
  }
  return results;
}

export function councilLabel(): string {
  return 'AI Council (sırayla · dört persona)';
}
