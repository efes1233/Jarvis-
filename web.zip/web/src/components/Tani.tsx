import { useState } from 'react';
import { token } from '../lib/api';
import { voice } from '../lib/speech';
import { SURUM } from '../lib/surum';

interface Saglayici { id: string; ad: string; anahtar: string; url: string; model: Record<string, string | null>; saglikli: boolean; sonHata: string | null }
interface BeyinDurum { mod: string; saglayicilar: Saglayici[]; roller: Record<string, string[]> }
interface DeneSonuc { id: string; ad: string; ok: boolean; ms: number; model: string | null; hata?: string }

const baslik = (): HeadersInit => ({ 'Content-Type': 'application/json', ...(token ? { 'x-jarvis-token': token } : {}) });

/** Ses denemesi: tarayıcı konuşma sentezi gerçekten çalıyor mu? Sessiz anahtarı, ses düzeyi ve izin sorunlarını ayırt eder. */
function sesDene(): Promise<string> {
  return new Promise(coz => {
    try {
      if (!('speechSynthesis' in window)) return coz('Bu tarayıcıda konuşma sentezi yok.');
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance('Test. Beni duyuyorsan ses çalışıyor.');
      u.lang = 'tr-TR';
      const tr = speechSynthesis.getVoices().find(v => /^tr/i.test(v.lang));
      if (tr) u.voice = tr;
      let basladi = false;
      u.onstart = () => { basladi = true; };
      u.onend = () => coz(basladi ? 'Ses çaldı. Duymadıysan telefonun yan sessiz anahtarını ve ses düzeyini kontrol et (iPhone web sesi sessiz modda çalmaz).' : 'Ses sentezi başlamadan bitti: tarayıcı sesi engelledi.');
      u.onerror = e => coz(`Ses hatası: ${e.error}`);
      speechSynthesis.speak(u);
      setTimeout(() => coz(basladi ? 'Ses çalıyor.' : 'Ses başlamadı: sessiz anahtarı, ses düzeyi ya da tarayıcı izni.'), 5000);
    } catch (e) {
      coz(`Ses denemesi başarısız: ${String((e as Error)?.message ?? e)}`);
    }
  });
}

/** Ayarlar: sürüm, beyin (yapay zekâ sağlayıcıları) durumu ve denemesi, ses denemesi. */
export function Tani() {
  const [beyin, setBeyin] = useState<BeyinDurum | null>(null);
  const [dene, setDene] = useState<DeneSonuc[] | null>(null);
  const [mesaj, setMesaj] = useState('');
  const [mesgul, setMesgul] = useState(false);
  const [ses, setSes] = useState('');

  const yukle = async () => {
    setMesgul(true); setMesaj('');
    try {
      const r = await fetch('/api/beyin', { headers: baslik() });
      if (!r.ok) throw new Error(r.status === 404 ? 'Bu sunucu sürümünde Beyin paneli yok (yama uygulanmamış).' : `HTTP ${r.status}`);
      setBeyin((await r.json()) as BeyinDurum);
    } catch (e) { setMesaj(String((e as Error)?.message ?? e)); }
    setMesgul(false);
  };
  const dena = async () => {
    setMesgul(true); setMesaj(''); setDene(null);
    try {
      const r = await fetch('/api/beyin/dene', { method: 'POST', headers: baslik() });
      const j = (await r.json()) as { sonuclar?: DeneSonuc[]; error?: string };
      if (!r.ok) throw new Error(j.error ?? `HTTP ${r.status}`);
      setDene(j.sonuclar ?? []);
      void yukle();
    } catch (e) { setMesaj(String((e as Error)?.message ?? e)); }
    setMesgul(false);
  };

  return (
    <>
      <label>Tanı</label>
      <p className="muted small">Sürüm: {SURUM}. Sunucu sesi: {voice.serverTts ? 'açık' : 'kapalı (tarayıcı sesi)'}.</p>
      <div className="seg">
        <button disabled={mesgul} onClick={yukle}>Beyin durumu</button>
        <button disabled={mesgul} onClick={dena}>Beyni dene</button>
        <button onClick={async () => setSes(await sesDene())}>Sesi dene</button>
      </div>
      {mesaj ? <p className="muted small">{mesaj}</p> : null}
      {ses ? <p className="muted small">{ses}</p> : null}
      {beyin ? (
        <p className="muted small">
          {beyin.saglayicilar.length === 0 ? 'Hiç yapay zekâ anahtarı yok: demo modu.' : `Mod: ${beyin.mod}.`}
          {beyin.saglayicilar.map(s => (
            <span key={s.id} style={{ display: 'block' }}>
              {s.saglikli ? '●' : '○'} {s.ad} ({s.anahtar}) · sohbet: {s.model.sohbet ?? 'olduğu gibi'} · derin: {s.model.derin ?? 'olduğu gibi'}{s.sonHata ? ` · son hata: ${s.sonHata}` : ''}
            </span>
          ))}
          {beyin.saglayicilar.length ? <span style={{ display: 'block' }}>Sıra: sohbet {beyin.roller.sohbet?.join(' → ')} · derin {beyin.roller.derin?.join(' → ')} · görüntü {beyin.roller.gorsel?.join(' → ')}</span> : null}
        </p>
      ) : null}
      {dene ? (
        <p className="muted small">
          {dene.map(d => (
            <span key={d.id} style={{ display: 'block' }}>{d.ok ? '✓' : '✗'} {d.ad}: {d.ok ? `${d.ms} ms · ${d.model}` : d.hata}</span>
          ))}
        </p>
      ) : null}
    </>
  );
}
