import { PERSONAS, type PersonaId } from '../ai/personas';

const ORDER: PersonaId[] = ['jarvis', 'friday', 'ev', 'edith'];

export function PersonaBar({ active, onChange }: { active: PersonaId; onChange: (id: PersonaId) => void }) {
  return (
    <div className="persona-bar" role="tablist" aria-label="Yapay zekâ kişiliği">
      {ORDER.map(id => {
        const p = PERSONAS[id];
        const on = id === active;
        return (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={on}
            className={on ? 'on' : ''}
            style={{ '--pc': p.renk } as React.CSSProperties}
            onClick={() => onChange(id)}
            title={p.kisa}
          >
            {p.ad}
          </button>
        );
      })}
    </div>
  );
}
