import { useRef, useState } from 'react';
import { token } from '../lib/api';

type Result = { model: string; text: string; note?: string };

export function VisionPanel({ acik, onKapat }: { acik: boolean; onKapat: () => void }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('Bu görseli açıkla. Yazıları oku (OCR). Nesneleri listele.');

  if (!acik) return null;

  const onFile = (f: File | null) => {
    if (!f) return;
    const r = new FileReader();
    r.onload = () => setPreview(String(r.result));
    r.readAsDataURL(f);
    setResult(null);
    setError(null);
  };

  const analyze = async () => {
    if (!preview) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/vision/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(token ? { 'x-jarvis-token': token } : {}) },
        body: JSON.stringify({ image: preview, prompt }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || 'analiz başarısız');
      setResult({ model: j.model, text: j.text, note: j.note });
    } catch (e: any) {
      setError(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="vision-panel" role="dialog" aria-label="Görsel analiz">
      <header>
        <span>E.D.I.T.H. · GÖRSEL ANALİZ</span>
        <button type="button" onClick={onKapat}>✕</button>
      </header>
      <p className="vision-note">API gerekir (VISION_MODEL / sağlayıcı anahtarı). Ücretsiz limitler sağlayıcıya bağlıdır.</p>
      <input ref={fileRef} type="file" accept="image/*" capture="environment" hidden onChange={e => onFile(e.target.files?.[0] || null)} />
      <div className="vision-actions">
        <button type="button" onClick={() => fileRef.current?.click()}>Foto seç / çek</button>
        <button type="button" disabled={!preview || loading} onClick={analyze}>{loading ? 'Analiz…' : 'Analiz et'}</button>
      </div>
      <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={2} aria-label="Analiz sorusu" />
      {preview && <img src={preview} alt="Yüklenen" className="vision-preview" />}
      {error && <p className="vision-err">{error}</p>}
      {result && (
        <div className="vision-result">
          <small>Model: {result.model}</small>
          <div>{result.text}</div>
          {result.note && <small className="muted">{result.note}</small>}
        </div>
      )}
    </div>
  );
}
