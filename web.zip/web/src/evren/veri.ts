// Evren · sabit veriler: gezegenler, temsili uydu takımları.
import { D, type Govde, type Yorunge } from './motor';

export const GOVDELER: Govde[] = [
  { id: 'gunes', ad: 'Güneş', aAU: 0, donemGun: 1, L0: 0, renk: '#ffd27a', yaricapKm: 696340, cap: '1.392.700 km', uzaklik: '—', yil: '—', gun: '≈ 25 gün (ekvatorda)', sicaklik: 'yüzey ≈ 5.500 °C', not: 'Sistemin kütlesinin %99,8\'i' },
  { id: 'merkur', ad: 'Merkür', aAU: 0.387, donemGun: 87.969, L0: 252.25, renk: '#b8a99a', yaricapKm: 2440, cap: '4.879 km', uzaklik: '57,9 milyon km', yil: '88 gün', gun: '58,6 gün', sicaklik: '−180 / +430 °C' },
  { id: 'venus', ad: 'Venüs', aAU: 0.723, donemGun: 224.701, L0: 181.98, renk: '#e8c88a', yaricapKm: 6052, cap: '12.104 km', uzaklik: '108,2 milyon km', yil: '224,7 gün', gun: '243 gün (ters yönde)', sicaklik: '≈ 465 °C', not: 'En sıcak gezegen' },
  { id: 'dunya', ad: 'Dünya', aAU: 1, donemGun: 365.256, L0: 100.46, renk: '#4da6ff', yaricapKm: 6371, cap: '12.742 km', uzaklik: '149,6 milyon km', yil: '365,25 gün', gun: '23 sa 56 dk', sicaklik: 'ortalama ≈ 15 °C' },
  { id: 'mars', ad: 'Mars', aAU: 1.524, donemGun: 686.98, L0: 355.45, renk: '#d96b43', yaricapKm: 3390, cap: '6.779 km', uzaklik: '227,9 milyon km', yil: '687 gün', gun: '24 sa 37 dk', sicaklik: 'ortalama ≈ −63 °C' },
  { id: 'jupiter', ad: 'Jüpiter', aAU: 5.203, donemGun: 4332.59, L0: 34.4, renk: '#d8b48a', yaricapKm: 69911, cap: '139.820 km', uzaklik: '778,5 milyon km', yil: '11,9 yıl', gun: '9 sa 56 dk', sicaklik: 'bulut tepesi ≈ −110 °C', bant: true, not: 'En büyük gezegen' },
  { id: 'saturn', ad: 'Satürn', aAU: 9.537, donemGun: 10759.22, L0: 49.95, renk: '#e3cf9c', yaricapKm: 58232, cap: '116.460 km', uzaklik: '1,43 milyar km', yil: '29,5 yıl', gun: '10 sa 33 dk', sicaklik: 'bulut tepesi ≈ −140 °C', bant: true, halka: true },
  { id: 'uranus', ad: 'Uranüs', aAU: 19.19, donemGun: 30688.5, L0: 313.24, renk: '#8fe0e6', yaricapKm: 25362, cap: '50.724 km', uzaklik: '2,87 milyar km', yil: '84 yıl', gun: '17 sa 14 dk', sicaklik: '≈ −195 °C', not: 'Yan yatmış döner' },
  { id: 'neptun', ad: 'Neptün', aAU: 30.07, donemGun: 60182, L0: 304.88, renk: '#5b7cff', yaricapKm: 24622, cap: '49.244 km', uzaklik: '4,50 milyar km', yil: '164,8 yıl', gun: '16 sa 6 dk', sicaklik: '≈ −200 °C' },
];

/** Gezegen sayfası için Ay (gezegen listesinde yörüngesi yok). */
export const AY: Govde = {
  id: 'ay', ad: 'Ay', aAU: 0, donemGun: 27.32, L0: 0, renk: '#cfcfcf', yaricapKm: 1737, cap: '3.474 km', uzaklik: 'Dünya\'ya 384.400 km',
  yil: '27,3 günde Dünya\'yı dolanır', gun: '27,3 gün (hep aynı yüzü bize)', sicaklik: '−173 / +127 °C',
};

export const govdeBul = (id: string): Govde | undefined => id === 'ay' ? AY : GOVDELER.find(g => g.id === id);

export interface Takim { id: string; ad: string; renk: string; hKm: number; egim: number; adet: number; duzlem: number }

/** TEMSİLİ uydu takımları: gerçek konumlar değil, gerçek yörünge türlerinin (yükseklik, eğim) görsel örneği. */
export const TAKIMLAR: Takim[] = [
  { id: 'leo', ad: 'Alçak yörünge ağı', renk: '#7df9ff', hKm: 550, egim: 53 * D, adet: 10, duzlem: 6 },
  { id: 'kutup', ad: 'Kutup yörüngesi', renk: '#a7ff7d', hKm: 750, egim: 98 * D, adet: 5, duzlem: 3 },
  { id: 'gps', ad: 'Konum (GPS tipi)', renk: '#ffd166', hKm: 20200, egim: 55 * D, adet: 4, duzlem: 6 },
  { id: 'geo', ad: 'Sabit (jeosenkron)', renk: '#ff8ad8', hKm: 35786, egim: 0, adet: 12, duzlem: 1 },
];

/** Takımları tek tek uydulara aç. */
export function uyduListesi(): { id: string; takim: Takim; y: Yorunge }[] {
  const out: { id: string; takim: Takim; y: Yorunge }[] = [];
  for (const t of TAKIMLAR) {
    for (let p = 0; p < t.duzlem; p++) {
      for (let i = 0; i < t.adet; i++) {
        out.push({
          id: `${t.id}-${p}-${i}`, takim: t,
          y: { hKm: t.hKm, egim: t.egim, dugum: ((p / t.duzlem) * 2 * Math.PI) % (2 * Math.PI), faz: (i / t.adet) * 2 * Math.PI + (p % 2) * (Math.PI / t.adet) },
        });
      }
    }
  }
  return out;
}

/** ISS: gerçek yörünge türü (eğim 51,6°, ≈ 420 km). Konum gerçek değilse temsilidir; gerçek konum alınabilirse üzerine yazılır. */
export const ISS: Yorunge = { hKm: 420, egim: 51.6 * D, dugum: 1.2, faz: 0.4 };
