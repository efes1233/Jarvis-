// Evren · senaryo hesapları: meteor çarpması (kaba, eğitim amaçlı) ve zamanlama. Saf mantık.

export interface MeteorGirdi { capKm: number; hizKms: number; aciDeg: number }
export interface MeteorSonuc {
  kutleKg: number; enerjiJ: number; megaton: number;
  hava: boolean; // atmosferde parçalanır mı (yaklaşık: taşlı cisim < 50 m)
  krater: number; // km (yer çarpması; hava patlamasında 0)
  sinif: string; etki: string;
}

const YOGUNLUK = 3000; // kg/m³ (taşlı asteroit)
const MEGATON_J = 4.184e15;

/** Çap/hız/açıdan kaba etki tahmini. Çarpma krateri: Collins vd. (2005) ölçek bağıntısı, basit krater düzeltmesiyle. */
export function meteorHesap(g: MeteorGirdi): MeteorSonuc {
  const L = Math.max(1, g.capKm * 1000);
  const v = Math.max(11, Math.min(72, g.hizKms)) * 1000;
  const aci = Math.max(15, Math.min(90, g.aciDeg)) * (Math.PI / 180);
  const m = YOGUNLUK * (4 / 3) * Math.PI * Math.pow(L / 2, 3);
  const E = 0.5 * m * v * v;
  const mt = E / MEGATON_J;
  const hava = L < 50;
  let krater = 0;
  if (!hava) {
    const gYer = 9.81, oran = YOGUNLUK / 2500;
    const gecici = 1.161 * Math.cbrt(oran) * Math.pow(L, 0.78) * Math.pow(v, 0.44) * Math.pow(gYer, -0.22) * Math.cbrt(Math.sin(aci));
    krater = (gecici * 1.25) / 1000;
  }
  let sinif: string, etki: string;
  if (mt < 0.001) { sinif = 'Küçük göktaşı'; etki = 'Yerde fark edilmeyebilir; parlak bir ateş topu görülür.'; }
  else if (mt < 1) { sinif = 'Ateş topu / hava patlaması'; etki = 'Şehir üzerinde patlarsa pencereler kırılır, yaralanmalar olur (Çelyabinsk 2013 ≈ 0,5 megaton).'; }
  else if (mt < 100) { sinif = 'Yerel yıkım'; etki = 'Şehir ölçeğinde yıkım; kıyıya yakınsa tsunami.'; }
  else if (mt < 1e5) { sinif = 'Bölgesel felaket'; etki = 'Ülke ölçeğinde yıkım, geniş yangınlar, kıyılarda büyük tsunami.'; }
  else { sinif = 'Küresel felaket'; etki = 'Küresel iklim etkisi ve kitlesel yok oluş riski (Chicxulub ölçeği).'; }
  return { kutleKg: m, enerjiJ: E, megaton: mt, hava, krater, sinif, etki };
}

export interface MeteorParam { lon: number; lat: number; capKm: number; hizKms: number; aciDeg: number; ad: string }

/** Zaman çizelgesi (saniye): yaklaşma → çarpma → şok dalgası → kül. */
export const METEOR_SURE = { yaklasma: 3.4, patlama: 1.1, dalga: 5.5, toplam: 12 };

export type Evre = 'yaklasma' | 'patlama' | 'dalga' | 'kul' | 'bitti';
export function meteorEvre(t: number): { evre: Evre; k: number } {
  const s = METEOR_SURE;
  if (t < s.yaklasma) return { evre: 'yaklasma', k: t / s.yaklasma };
  if (t < s.yaklasma + s.patlama) return { evre: 'patlama', k: (t - s.yaklasma) / s.patlama };
  if (t < s.yaklasma + s.patlama + s.dalga) return { evre: 'dalga', k: (t - s.yaklasma - s.patlama) / s.dalga };
  if (t < s.toplam) return { evre: 'kul', k: (t - s.yaklasma - s.patlama - s.dalga) / (s.toplam - s.yaklasma - s.patlama - s.dalga) };
  return { evre: 'bitti', k: 1 };
}

/** "12 km", "850 m" gibi okunur uzunluk. */
export function uzunluk(km: number): string {
  if (km >= 100) return `${Math.round(km)} km`;
  if (km >= 1) return `${km.toFixed(1).replace('.', ',')} km`;
  return `${Math.round(km * 1000)} m`;
}
/** "0,5 megaton", "1,2 milyon megaton" */
export function enerjiMetni(mt: number): string {
  if (mt < 0.01) return `${(mt * 1000).toFixed(1).replace('.', ',')} kiloton`;
  if (mt < 1000) return `${mt.toFixed(mt < 10 ? 1 : 0).replace('.', ',')} megaton`;
  if (mt < 1e6) return `${Math.round(mt / 1000).toLocaleString('tr-TR')} bin megaton`;
  return `${(mt / 1e6).toFixed(1).replace('.', ',')} milyon megaton`;
}
