import { useEffect, useRef } from 'react';
import { LAND } from '../data/world';

export interface GlobeMarker { lon: number; lat: number; label: string; hot?: boolean }

const D = Math.PI / 180;
const RINGS: Float32Array[] = LAND.map(s => Float32Array.from(s.split(',').map(Number), v => v * D));

export type OrbitBody = "dunya" | "ay" | "mars" | "jupiter";

const BODY_STYLE: Record<OrbitBody, { fill: string; fill2: string; stroke: string; glow: string; label: string; spin: number }> = {
  dunya: { fill: "rgba(12,40,80,0.85)", fill2: "rgba(30,90,140,0.5)", stroke: "rgba(120,220,255,0.85)", glow: "rgba(0,200,255,0.35)", label: "DÜNYA", spin: 8 },
  ay: { fill: "rgba(50,52,58,0.9)", fill2: "rgba(90,92,100,0.5)", stroke: "rgba(210,215,220,0.8)", glow: "rgba(200,210,220,0.25)", label: "AY", spin: 3 },
  mars: { fill: "rgba(90,30,18,0.9)", fill2: "rgba(160,60,30,0.45)", stroke: "rgba(255,140,90,0.85)", glow: "rgba(255,100,50,0.3)", label: "MARS", spin: 6 },
  jupiter: { fill: "rgba(100,70,40,0.85)", fill2: "rgba(180,130,70,0.4)", stroke: "rgba(255,200,120,0.8)", glow: "rgba(255,180,80,0.3)", label: "JÜPİTER", spin: 12 },
};

/**
 * Sinematik tel kafes küre — atmosfer parıltısı, tarama yayı, nabız işaretler, yörünge halkası.
 * Temsili sci-fi simülasyon; gerçek zamanlı uydu telemetrisi değildir.
 */
export function Globe({ markers, focus, body = "dunya", quality = "high" }: {
  markers: GlobeMarker[];
  focus: [number, number] | null;
  body?: OrbitBody;
  quality?: "high" | "low";
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const mRef = useRef(markers);
  mRef.current = markers;
  const fRef = useRef(focus);
  fRef.current = focus;
  const bRef = useRef(body);
  bRef.current = body;
  const qRef = useRef(quality);
  qRef.current = quality;

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext('2d')!;
    let raf = 0, w = 0, h = 0, dpr = 1;
    let lon0 = 20 * D, lat0 = 25 * D;
    let last = performance.now();
    let scanA = 0;

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, qRef.current === 'low' ? 1 : 2);
      const r = canvas.getBoundingClientRect();
      w = r.width; h = r.height;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    resize();

    const draw = (t: number) => {
      const dt = Math.min(0.1, (t - last) / 1000);
      last = t;
      const low = qRef.current === 'low';
      const style = BODY_STYLE[bRef.current] || BODY_STYLE.dunya;
      const f = fRef.current;

      if (f) {
        let dl = f[0] * D - lon0;
        dl = Math.atan2(Math.sin(dl), Math.cos(dl));
        lon0 += dl * Math.min(1, dt * 2.2);
        lat0 += (Math.min(60, Math.max(-60, f[1])) * D - lat0) * Math.min(1, dt * 2.2);
      } else {
        lon0 += dt * (low ? style.spin * 0.45 : style.spin) * D;
        lat0 += (25 * D - lat0) * Math.min(1, dt);
      }
      scanA = (scanA + dt * (low ? 0.6 : 1.1)) % (Math.PI * 2);

      const sinP = Math.sin(lat0), cosP = Math.cos(lat0);
      const R = Math.min(w, h) / 2 - 18;
      if (R <= 4) { raf = requestAnimationFrame(draw); return; }
      const cx = w / 2, cy = h / 2;

      const proj = (lam: number, phi: number): [number, number, number] | null => {
        const cosPhi = Math.cos(phi), dl = lam - lon0;
        const cosc = sinP * Math.sin(phi) + cosP * cosPhi * Math.cos(dl);
        if (cosc < -0.05) return null;
        const k = R;
        const x = k * cosPhi * Math.sin(dl);
        const y = k * (cosP * Math.sin(phi) - sinP * cosPhi * Math.cos(dl));
        return [cx + x, cy - y, cosc];
      };

      ctx.clearRect(0, 0, w, h);

      // Dış atmosfer glow
      const ag = ctx.createRadialGradient(cx, cy, R * 0.7, cx, cy, R * 1.25);
      ag.addColorStop(0, 'transparent');
      ag.addColorStop(0.55, style.glow);
      ag.addColorStop(1, 'transparent');
      ctx.fillStyle = ag;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 1.25, 0, Math.PI * 2);
      ctx.fill();

      // Gövde dolgu + terminator
      const bg = ctx.createRadialGradient(cx - R * 0.35, cy - R * 0.3, R * 0.1, cx, cy, R);
      bg.addColorStop(0, style.fill2);
      bg.addColorStop(0.55, style.fill);
      bg.addColorStop(1, 'rgba(0,0,0,0.55)');
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fillStyle = bg;
      ctx.fill();

      // Kenar halkası
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.strokeStyle = style.stroke;
      ctx.lineWidth = low ? 1 : 1.5;
      ctx.shadowColor = style.glow;
      ctx.shadowBlur = low ? 0 : 12;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Yörünge halkası (eğik elips)
      if (!low) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(-0.35);
        ctx.scale(1, 0.32);
        ctx.beginPath();
        ctx.arc(0, 0, R * 1.18, 0, Math.PI * 2);
        ctx.strokeStyle = style.stroke.replace(/[\d.]+\)$/, '0.35)');
        ctx.lineWidth = 1;
        ctx.stroke();
        // Halka üzerinde hareketli nokta
        const ox = Math.cos(t * 0.0012) * R * 1.18;
        const oy = Math.sin(t * 0.0012) * R * 1.18;
        ctx.beginPath();
        ctx.arc(ox, oy, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = style.stroke;
        ctx.fill();
        ctx.restore();
      }

      // Izgara
      const line = (pts: [number, number][]) => {
        let on = false;
        ctx.beginPath();
        for (const [l, p] of pts) {
          const q = proj(l, p);
          if (!q) { on = false; continue; }
          if (on) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]);
          on = true;
        }
        ctx.stroke();
      };
      ctx.strokeStyle = style.stroke.replace(/[\d.]+\)$/, '0.22)');
      ctx.lineWidth = 0.6;
      const step = low ? 45 : 30;
      for (let l = -180; l < 180; l += step) line(Array.from({ length: 37 }, (_, i) => [l * D, (-90 + i * 5) * D]));
      for (let p = -60; p <= 60; p += step) line(Array.from({ length: 73 }, (_, i) => [(-180 + i * 5) * D, p * D]));

      // Kıyılar (yalnızca Dünya)
      if (bRef.current === 'dunya') {
        ctx.strokeStyle = style.stroke;
        ctx.lineWidth = low ? 0.8 : 1.1;
        for (const r of RINGS) {
          let on = false;
          ctx.beginPath();
          for (let i = 0; i < r.length; i += 2) {
            const q = proj(r[i], r[i + 1]);
            if (!q) { on = false; continue; }
            if (on) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]);
            on = true;
          }
          ctx.stroke();
        }
      }

      // Tarama yayı (sci-fi radar)
      if (!low) {
        const sweep = scanA;
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, R, sweep - 0.5, sweep, false);
        ctx.closePath();
        const sg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R);
        sg.addColorStop(0, style.glow);
        sg.addColorStop(1, 'transparent');
        ctx.fillStyle = sg;
        ctx.globalAlpha = 0.25;
        ctx.fill();
        ctx.globalAlpha = 1;
        ctx.restore();
      }

      // Yıldız / parçacık (arka plan, küre dışı)
      if (!low) {
        ctx.fillStyle = 'rgba(180,220,255,0.5)';
        for (let i = 0; i < 40; i++) {
          const a = (i * 2.4 + t * 0.00005) % (Math.PI * 2);
          const rr = R * 1.35 + (i % 7) * 6;
          const px = cx + Math.cos(a) * rr;
          const py = cy + Math.sin(a) * rr * 0.85;
          ctx.fillRect(px, py, 1.2, 1.2);
        }
      }

      // İşaretler — nabız
      const pulse = 0.5 + 0.5 * Math.sin(t * 0.006);
      for (const m of mRef.current) {
        const q = proj(m.lon * D, m.lat * D);
        if (!q) continue;
        const [x, y] = q;
        const rad = m.hot ? 5 + pulse * 3 : 3.5;
        ctx.beginPath();
        ctx.arc(x, y, rad + 4, 0, Math.PI * 2);
        ctx.strokeStyle = m.hot ? 'rgba(255,80,80,0.45)' : style.glow;
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(x, y, rad, 0, Math.PI * 2);
        ctx.fillStyle = m.hot ? '#ff5555' : style.stroke;
        ctx.fill();
        if (m.label) {
          ctx.font = '10px monospace';
          ctx.fillStyle = '#cfefff';
          ctx.fillText(m.label, x + 8, y - 4);
        }
      }

      // Etiket
      ctx.fillStyle = style.stroke;
      ctx.font = '11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(style.label + (low ? ' · LITE' : ' · ORBIT'), cx, cy + R + 14);
      ctx.textAlign = 'left';

      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, []);

  return <canvas ref={ref} className="m2-globe m2-globe-fx" aria-label="Orbit simülasyonu" />;
}
