import { useEffect, useRef, useState } from "react";

const FRAGMANLAR = [
  { id: "1", baslik: "Uzay İstasyonu", url: "https://assets.mixkit.co/videos/preview/mixkit-flying-over-the-earth-from-space-2502-large.mp4" },
  { id: "2", baslik: "Şehir Gece", url: "https://assets.mixkit.co/videos/preview/mixkit-city-traffic-at-night-from-above-4399-large.mp4" },
  { id: "3", baslik: "Teknoloji HUD", url: "https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-futuristic-devices-4350-large.mp4" },
  { id: "4", baslik: "Yıldızlar", url: "https://assets.mixkit.co/videos/preview/mixkit-stars-in-space-background-1610-large.mp4" },
  { id: "5", baslik: "Neon Şehir", url: "https://assets.mixkit.co/videos/preview/mixkit-aerial-view-of-city-traffic-at-night-11-large.mp4" },
];

const FILM_SITELERI = [
  { ad: "FullHDFilmizle", url: "https://www.fullhdfilmizlesene.now/" },
  { ad: "HDFilmCehennemi", url: "https://www.hdfilmcehennemi.nl/" },
  { ad: "FilmMakinesi", url: "https://filmmakinesi.to/" },
  { ad: "JustWatch TR", url: "https://www.justwatch.com/tr/filmler" },
];

type FilmKayit = { id: string; baslik: string; url?: string; at: number };

function loadList(key: string): FilmKayit[] {
  try { return JSON.parse(localStorage.getItem(key) || "[]"); } catch { return []; }
}
function saveList(key: string, list: FilmKayit[]) {
  try { localStorage.setItem(key, JSON.stringify(list.slice(0, 50))); } catch {}
}

type Props = {
  acik: boolean;
  onKapat: () => void;
  onTamEkran: (url: string) => void;
  sesliIstek?: string | null;
};

export default function SinemaPaneli({ acik, onKapat, onTamEkran, sesliIstek }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [aktif, setAktif] = useState(0);
  const [otomatik, setOtomatik] = useState(true);
  const [site, setSite] = useState(0);
  const [tab, setTab] = useState<"oynat" | "favori" | "liste" | "gecmis">("oynat");
  const [favoriler, setFavoriler] = useState<FilmKayit[]>(() => loadList("jarvis.sinema.favori"));
  const [izleme, setIzleme] = useState<FilmKayit[]>(() => loadList("jarvis.sinema.izleme"));
  const [gecmis, setGecmis] = useState<FilmKayit[]>(() => loadList("jarvis.sinema.gecmis"));
  const [arama, setArama] = useState("");

  useEffect(() => {
    if (!acik || !otomatik) return;
    const t = setInterval(() => setAktif((i) => (i + 1) % FRAGMANLAR.length), 28000);
    return () => clearInterval(t);
  }, [acik, otomatik]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v || !acik) return;
    v.load();
    v.play().catch(() => {});
  }, [aktif, acik]);

  useEffect(() => {
    if (!sesliIstek || !acik) return;
    const q = sesliIstek.toLowerCase().trim();
    let filmAdi = sesliIstek;
    const match = q.match(/(?:film aç|film ac|sinema aç|tam ekran film|fragman|film izle)\s+(.+)/i);
    if (match) filmAdi = match[1].trim();
    let hedef = FILM_SITELERI[0].url;
    if (q.includes("hdfilm") || q.includes("cehennem")) hedef = FILM_SITELERI[1].url;
    else if (q.includes("makine")) hedef = FILM_SITELERI[2].url;
    else if (q.includes("just") || q.includes("watch")) hedef = FILM_SITELERI[3].url;
    const kayit: FilmKayit = { id: String(Date.now()), baslik: filmAdi, url: hedef, at: Date.now() };
    setGecmis(g => { const n = [kayit, ...g]; saveList("jarvis.sinema.gecmis", n); return n; });
    if (hedef.includes("justwatch") && filmAdi.length > 2) {
      onTamEkran("https://www.justwatch.com/tr/arama?q=" + encodeURIComponent(filmAdi));
    } else {
      onTamEkran(hedef);
    }
  }, [sesliIstek, acik, onTamEkran]);

  const ekleFavori = (baslik: string, url?: string) => {
    const kayit: FilmKayit = { id: String(Date.now()), baslik, url, at: Date.now() };
    setFavoriler(g => { const n = [kayit, ...g.filter(x => x.baslik !== baslik)]; saveList("jarvis.sinema.favori", n); return n; });
  };
  const ekleIzleme = (baslik: string, url?: string) => {
    const kayit: FilmKayit = { id: String(Date.now()), baslik, url, at: Date.now() };
    setIzleme(g => { const n = [kayit, ...g.filter(x => x.baslik !== baslik)]; saveList("jarvis.sinema.izleme", n); return n; });
  };

  if (!acik) return null;
  const frag = FRAGMANLAR[aktif];

  return (
    <div className="sinema-panel" role="dialog" aria-label="Sinema Ekranı">
      <header>
        <span>SİNEMA</span>
        <div className="sinema-kontroller">
          <button type="button" onClick={() => setOtomatik(!otomatik)}>{otomatik ? "⏸" : "▶"}</button>
          <button type="button" onClick={() => setAktif((i) => (i + 1) % FRAGMANLAR.length)}>⏭</button>
          <button type="button" onClick={onKapat}>✕</button>
        </div>
      </header>
      <div className="sinema-tabs">
        {(["oynat", "favori", "liste", "gecmis"] as const).map(t => (
          <button key={t} type="button" className={tab === t ? "aktif" : ""} onClick={() => setTab(t)}>
            {t === "oynat" ? "Oynat" : t === "favori" ? "Favori" : t === "liste" ? "Liste" : "Geçmiş"}
          </button>
        ))}
      </div>
      {tab === "oynat" && (
        <>
          <div className="sinema-ekran">
            <video ref={videoRef} key={frag.id} src={frag.url} muted playsInline loop={!otomatik}
              onEnded={() => otomatik && setAktif((i) => (i + 1) % FRAGMANLAR.length)} />
            <div className="sinema-baslik">{frag.baslik}</div>
          </div>
          <div className="sinema-row">
            <button type="button" onClick={() => ekleFavori(frag.baslik, frag.url)}>★ Favori</button>
            <button type="button" onClick={() => ekleIzleme(frag.baslik, frag.url)}>+ Liste</button>
          </div>
          <div className="sinema-siteler">
            {FILM_SITELERI.map((s, i) => (
              <button key={s.ad} type="button" className={i === site ? "aktif" : ""}
                onClick={() => { setSite(i); onTamEkran(s.url); const k = { id: String(Date.now()), baslik: s.ad, url: s.url, at: Date.now() }; setGecmis(g => { const n = [k, ...g]; saveList("jarvis.sinema.gecmis", n); return n; }); }}>
                {s.ad}
              </button>
            ))}
          </div>
        </>
      )}
      {tab !== "oynat" && (
        <div className="sinema-list">
          <input placeholder="Film adı ekle…" value={arama} onChange={e => setArama(e.target.value)}
            onKeyDown={e => {
              if (e.key === "Enter" && arama.trim()) {
                if (tab === "favori") ekleFavori(arama.trim());
                if (tab === "liste") ekleIzleme(arama.trim());
                setArama("");
              }
            }} />
          {(tab === "favori" ? favoriler : tab === "liste" ? izleme : gecmis).map(k => (
            <div key={k.id} className="sinema-item">
              <span>{k.baslik}</span>
              {k.url && <button type="button" onClick={() => onTamEkran(k.url!)}>Aç</button>}
            </div>
          ))}
          {(tab === "favori" ? favoriler : tab === "liste" ? izleme : gecmis).length === 0 && (
            <p className="sinema-ipucu">Henüz kayıt yok.</p>
          )}
        </div>
      )}
      <p className="sinema-ipucu">Sesli: «film aç …» · Siteler yeni sekmede (yasal keşif / kendi kaynakların).</p>
    </div>
  );
}
