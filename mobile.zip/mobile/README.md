# Jarvis Mobil (iOS / Android, Capacitor)

Bu klasör, Jarvis'i telefona gerçek bir uygulama olarak kuran Capacitor kabuğudur.

**Nasıl çalışır:** Uygulama içine arayüz gömülmez. Uygulamanın WebView'ı, bilgisayarında çalışan Jarvis sunucusunu (HTTPS) açar. Beyin, ses, haber, kamera ve ev kontrolü zaten sunucuda olduğu için sunucu kodunda değişiklik gerekmez. Sunucuyu güncelleyince uygulama da güncellenir.

**Gerekenler**
- Jarvis sunucusu HTTPS ile erişilebilir olmalı (Tailscale `https://<bilgisayar>.<tailnet>.ts.net` ya da Cloudflare tüneli; ana README'deki "Telefon ve tablette kullanmak").
- `server/.env` içinde `ACCESS_TOKEN` tanımlı olmalı (adres internetten erişilebiliyorsa şart).
- iOS için Mac + Xcode, Android için Android Studio. Node.js 20+.

## Kurulum

```bash
cd mobile
npm run setup                       # Capacitor paketlerini kurar

# iOS
JARVIS_URL=https://bilgisayarim.tailnet-adi.ts.net npm run add:ios
npm run open:ios                    # Xcode açılır: Signing → kendi Apple ID'nizi seçin → ▶

# Android
JARVIS_URL=https://bilgisayarim.tailnet-adi.ts.net npm run add:android
npm run open:android                # Android Studio açılır: ▶
```

İlk açılışta "ERİŞİM ANAHTARI" ekranı çıkar: `server/.env` içindeki `ACCESS_TOKEN` değerini yapıştırın. Anahtar uygulamada saklanır, bir daha sorulmaz.

## Adres değişirse
```bash
JARVIS_URL=https://yeni-adres npm run sync
```
Sonra uygulamayı Xcode / Android Studio'dan yeniden yükleyin. (Cloudflare'ın ücretsiz hızlı tüneli her başlatmada adres değiştirir; kalıcı adres için Tailscale ya da adlandırılmış tünel kullanın.)

## Betikler
| Komut | Ne yapar |
|---|---|
| `npm run add:ios` / `add:android` | Platform projesini oluşturur, mikrofon/kamera izinlerini yazar, senkronlar |
| `npm run sync` | Adres ya da izin değiştikten sonra projeleri günceller |
| `scripts/patch-native.mjs` | `Info.plist` ve `AndroidManifest.xml` izinlerini ekler (tekrar çalıştırmak güvenli) |
| `scripts/prepare.mjs` | Sunucuya ulaşılamayınca görünen "yeniden dene" ekranını üretir |

## Bilinen sınırlar
- **Sunucu kapalıysa uygulama boş kalır**; "ÇEVRİMDIŞI · yeniden dene" ekranı görünür. Zaten her şey sunucuda çalışıyor.
- **Ekranın kapanmaması:** Web "Screen Wake Lock" API'si iOS WebView'larında her sürümde çalışmayabilir. Çalışmazsa kamera cihazı rolündeki telefonda *Ayarlar → Ekran ve Parlaklık → Otomatik Kilit: Asla* yapın.
- **Arka planda mikrofon** (alkışla uyandırma): iOS uygulama arka plana geçince mikrofonu keser. Uyandırma yalnızca uygulama ön plandayken çalışır.
- **Service worker / çevrimdışı önbellek** WebView'da kullanılamayabilir. Arayüz bunsuz da çalışır (kod `navigator.serviceWorker?.` ile korunuyor).
- **App Store / Play Store:** Bu, sunucuyu açan ince bir kabuktur. Kişisel kullanım (Xcode ile kendi telefonuna yükleme, APK) için uygundur. Apple, yalnızca web sitesi gösteren uygulamaları genellikle reddeder; mağazaya çıkmak isterseniz arayüzü pakete gömmek ve bildirim, paylaşım gibi yerel özellikler eklemek gerekir.
- iOS'ta ücretsiz Apple ID ile yüklenen uygulama 7 gün sonra süresi dolar (yeniden yüklemeniz gerekir); ücretli geliştirici hesabında bu sınır yoktur.
- `npm run setup` Capacitor'un güncel sürümünü kurar. Bu betikleri ben ortamımda gerçek bir `cap add` ile deneyemedim (ağ kapalı, Xcode/Android SDK yok); yalnızca sahte `Info.plist` ve manifest üzerinde sınadım.
