# GitHub'a iPhone/iPad üzerinden yükleme

Bu depo 100'den fazla dosya içerdiği için GitHub'ın tarayıcıdan tek seferde dosya yükleme sınırına takılmamak gerekir. ZIP dosyasını deponun içine kaynak kod diye yüklemeyin; ZIP'i bilgisayarda açıp içindeki proje dosyalarını yüklemek gerekir.

## En az hata çıkaran yöntem

1. GitHub'da yeni ve **Private** bir depo oluşturun.
2. Bu ZIP'i Dosyalar uygulamasında açın. İçindeki `jarvis-main` klasörüne girin.
3. `Add file → Upload files` ile önce klasörün içindeki ana dosya ve klasörleri yükleyin. Çok sayıda dosya seçmek iPhone'da sorun çıkarırsa iki veya daha fazla parti halinde yükleyin; her partide önceki dosyaları silmeyin.
4. Yüklemede `.github` klasörünün ve içindeki `workflows/check.yml` dosyasının da geldiğini kontrol edin. GitHub web yükleyicisi noktayla başlayan klasörleri göstermiyorsa bu dosyayı GitHub'ın `Add file → Create new file` ekranında `.github/workflows/check.yml` yoluyla ayrıca oluşturup içeriğini kopyalayın.
5. Bütün dosyalar yüklendikten sonra `Actions` sekmesine girin. `Jarvis checks` çalışması otomatik başlar. Yeşil tik görmeden derleme başarılı kabul edilmez.
6. Başarısız olursa Actions → `Jarvis checks` → `web-build` → kırmızı adım → log ekranındaki ilk gerçek hata satırını paylaşın. Hata görülmeden rastgele dosya değiştirmeyin.

## Önemli

- `server/.env` veya API anahtarlarını GitHub'a yüklemeyin. `.env` gizli kalmalıdır.
- Bu workflow yalnızca web arayüzünü derler ve çıktıyı Actions artifact olarak saklar. Render'a otomatik dağıtım yapmaz.
- iPhone Safari'de GitHub dosya yükleme arayüzü sorun çıkarırsa bu bir kaynak kod hatası değildir. Dosya yüklemeyi masaüstü görünümünde deneyin veya GitHub mobil uygulaması yerine Safari kullanın.
