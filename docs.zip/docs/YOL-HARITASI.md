# Jarvis yol haritası

Durumlar: ✅ yapıldı ve sınandı · 🟡 yazıldı, gerçek cihazda denenmedi · 🧱 temeli hazır, arayüze bağlanacak · 🔭 planlı · ⛔ yapılmayacak

## Şimdi (bu sürüm)
| | Özellik | Not |
|---|---|---|
| 🟡 | **Canlı dinleme** (tuşsuz): "Jarvis" deyince aktif olur, cevaptan sonra birkaç sn "Jarvis" demeden devam | Tarayıcı ses tanıması (Chrome/Edge/Android iyi, iPhone sınırlı). Kelime eşleştirme ve durum makinesi sahte mikrofonla 24 testten geçti |
| ✅ | **"Efendim" ve resmî hitap kaldırıldı** | Kişilik "sen" diliyle, sakin ve kısa; sunucu, arayüz ve hazır cümleler |
| 🟡 | **Gemini ses modeli** (Jarvis tonu stil komutuyla, 12 hazır ses) | Ayarlar → ses listesinde "· Gemini". Ücretsiz katman kotası ve sahne sahne perde tutarlılığı denenmeli |
| ✅ | Model kapanınca otomatik yedek model, Türkçe hata mesajları | Gemini sohbet ve ses için |
| ✅ | **Çok sağlayıcılı beyin**: Gemini, OpenAI, Claude, Grok, Groq, DeepSeek, Mistral, OpenRouter; işe göre yönlendirme, otomatik model seçimi, hata olunca sıradakine geçme, Tanı paneli | Sahte sağlayıcı sunucularıyla 44+12 testten geçti; gerçek anahtarlarla denenmedi. Bkz. BEYIN.md |
| ✅ | 10 yeni araç: birim çevirme, tarih/yaş hesabı, zar/rastgele, dünya saati, ay evresi, kredi, uyku, burç, sayıyı yazıya, son depremler | Hesaplar gerçek değerlerle doğrulandı; deprem servisi ağda denenmedi |
| 🟡 | iPhone'a göre el kontrolü performansı, yeni jestler (🤘 🤙 🖖), renk temaları, ses karakterleri | |
| 🟡 | Hafıza yedeği (sunucu uyuyunca silinmesin) | |
| ✅ | Hesap makinesi, namaz vakitleri araçları | |

## Sıradaki (öncelik sırasıyla)
1. 🧱 **Evren modu**: 3B Dünya (gerçek kıyı verisiyle), uydu takımları ve ISS, Güneş sistemi, gezegen sayfaları, "meteor düşsün" senaryosu, eller ve sesle döndürme/yakınlaştırma. Matematik, veri ve çizim motoru yazıldı ve fizik değerleriyle doğrulandı (ISS dönemi, jeosenkron sabitlik, Çelyabinsk ≈ 0,5 megaton). Kalan: ekran bileşeni, sesli komut aracı, el bağlantısı.
2. 🔭 **Araya girme**: Jarvis konuşurken "Jarvis dur" ile susturma (şimdi konuşurken dinleme duruyor, kendi sesini duymasın diye).
3. 🔭 **3B el taraması**: elin 21 noktasının dönen, tarama çizgili hologramı.
4. 🔭 **Gerçek uyandırma kelimesi**: cihazda çalışan (ses buluta gitmeyen) bir "Jarvis" dedektörü. Porcupine gibi motorlar "Jarvis" kelimesini hazır sunuyor; erişim anahtarı ve gerçek cihazda deneme gerekir.
5. 🔭 **Gerçek canlı konuşma**: Gemini Live API ile çift yönlü ses (araya girme, düşük gecikme). Ayrı bir mimari iş.
6. 🔭 **Film/fragman oynatma**: YouTube API anahtarıyla resmî film ve fragmanlar; kendi video dosyaların için oynatıcı paneli.
7. 🔭 **Yüz ağı** (face mesh) görseli.
8. 🔭 Çevrimdışı Türkçe ses (Piper vb.) ve kalıcı veri için ücretsiz veritabanı.

## Yapılmayacaklar
- ⛔ **Filmdeki Jarvis'in (aktörün) sesinin kopyası.** İnternetteki "Jarvis ses modelleri" gerçek bir oyuncunun sesinin telifli film sesinden çıkarılmış klonlarıdır; izinsiz ses taklidi ve telif sorunu doğurur. Bunun yerine stil komutuyla yönlendirilen lisanslı sentetik sesler kullanılır.
- ⛔ **Gerçek dudak okuma**: tarayıcıda güvenilir çalışmaz. Yalnızca "konuşuyor mu / ağız açıklığı" algılaması düşünülebilir.
- ⛔ **Başkalarının yüzünü tanıma**: gizlilik.
- ⛔ Korumalı yayınlar (Netflix vb.) oynatma.

## Bilinen sınırlar
- Canlı dinleme açıkken mikrofon sürekli dinler; konuşmalar tarayıcının ses tanıma servisine gider (Chrome: Google, Safari: Apple). İsteğe bağlı açılır, varsayılan kapalıdır.
- iPhone'da ekran kapanınca ya da uygulama arka plana geçince dinleme durur; iOS buna izin vermez.
- Gemini TTS'te aynı ses kimliği sahneden sahneye hafifçe farklı perdede çıkabilir (projenin kendi ölçümü). Olursa tarayıcı sesine dönülür.
- Ücretsiz sunucu 15 dk kullanılmazsa uyur; ilk açılış ~1 dk sürer.
